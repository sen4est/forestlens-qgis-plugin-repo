# -*- coding: utf-8 -*-
"""
Script to encrypt evalscript templates for QGIS plugin

Run this once to generate encrypted evalscripts
"""

from cryptography.fernet import Fernet
import base64
import hashlib

# Generate encryption key from a passphrase
# This key will be embedded in the plugin code (obfuscated)
PASSPHRASE = b"ForestLens-QGIS-Evalscripts-2024-v1"
key = base64.urlsafe_b64encode(hashlib.sha256(PASSPHRASE).digest())
fernet = Fernet(key)

print(f"Encryption key: {key.decode()}")
print()

# Evalscript templates (partial - will fill from TypeScript)
# These are the core evalscript structures that need IP protection

evalscripts = {
    "linear_regression": """//VERSION=3
/*
True Linear Regression Analysis for NDVI Trend Detection
Description: Fits linear regression through yearly NDVI averages
*/

const param = {{
  default: {{
    startYear: {startYear},
    endYear: {endYear},
    targetMonths: [{targetMonths}],
    maxCloudCoveragePercent: {maxCloudCoverage},
    ndviMinValue: -1,
    currentIndexesMinValuesNumber: 1
  }},
  linearRegression: {{
    pixelEvalMaxValue: {pixelEvalMaxValue}
  }}
}};

function setup() {{
  return {{
    input: [{{
      bands: ["B04", "B08", "SCL", "dataMask"]
    }}],
    output: {{ bands: 3 }},
    mosaicking: "ORBIT"
  }};
}}

function preProcessScenes(collections) {{
  const startYear = param.default.startYear;
  const endYear = param.default.endYear;
  const maxCloudCoveragePercent = param.default.maxCloudCoveragePercent;
  const targetMonths = param.default.targetMonths;

  collections.scenes.orbits = collections.scenes.orbits.filter(function (orbit) {{
    var orbitDateFrom = new Date(orbit.dateFrom);
    var orbitYear = orbitDateFrom.getFullYear();
    var currentMonth = orbitDateFrom.getMonth() + 1;

    var isCorrectYearRange = orbitYear >= startYear && orbitYear <= endYear;
    var isCorrectMonth = targetMonths.indexOf(currentMonth) !== -1;
    var isLowCloudCoverage = !orbit.cloudCoverage || orbit.cloudCoverage < maxCloudCoveragePercent;

    return isCorrectYearRange && isCorrectMonth && isLowCloudCoverage;
  }});

  return collections;
}}

var calculateNDVI = function calculateNDVI(sample, configParam) {{
  var denom = sample.B04 + sample.B08;
  if (denom === 0) return null;
  var result = (sample.B08 - sample.B04) / denom;
  return result > configParam.ndviMinValue ? result : null;
}};

var isSLCMasked = function isSLCMasked(sample) {{
  if (sample.SCL !== undefined && sample.SCL !== null) {{
    return (
      sample.SCL === 0 || sample.SCL === 1 || sample.SCL === 3 ||
      sample.SCL === 8 || sample.SCL === 9 || sample.SCL === 10 || sample.SCL === 11
    );
  }}
  return false;
}};

var calculateIndexesForSamples = function calculateIndexesForSamples(samples, scenes, configParam, processSampleMethod) {{
  if (samples.length !== scenes.length) throw new Error('samples and scenes arrays do not have same length');

  return samples.reduce(function (acc, sample, index) {{
    if (isSLCMasked(sample)) return acc;

    var indexValue = processSampleMethod(sample, configParam);
    if (!indexValue) return acc;

    var sceneYear = scenes[index].date.getFullYear();

    if (!acc[sceneYear]) {{
      acc[sceneYear] = {{ count: 0, sum: 0 }};
    }}

    acc[sceneYear].count++;
    acc[sceneYear].sum += indexValue;
    return acc;
  }}, {{}});
}};

function calculateLinearRegression(indexes, startYear, endYear) {{
  var dataPoints = [];

  for (var year = startYear; year <= endYear; year++) {{
    if (indexes[year] && indexes[year].count > 0) {{
      var yearlyAverage = indexes[year].sum / indexes[year].count;
      dataPoints.push({{ year: year, ndvi: yearlyAverage }});
    }}
  }}

  if (dataPoints.length < 2) return null;
  if (endYear <= startYear) return null;

  var n = dataPoints.length;
  var sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;

  for (var i = 0; i < n; i++) {{
    sumX += dataPoints[i].year;
    sumY += dataPoints[i].ndvi;
    sumXY += dataPoints[i].year * dataPoints[i].ndvi;
    sumX2 += dataPoints[i].year * dataPoints[i].year;
  }}

  var denominator = n * sumX2 - sumX * sumX;
  if (denominator === 0) return null;

  var slope = (n * sumXY - sumX * sumY) / denominator;
  var intercept = (sumY - slope * sumX) / n;

  return {{
    slope: slope,
    intercept: intercept,
    dataPoints: dataPoints,
    yearSpan: endYear - startYear
  }};
}}

function evaluatePixel(samples, scenes) {{
  var indexes = calculateIndexesForSamples(samples, scenes, param["default"], calculateNDVI);
  var regression = calculateLinearRegression(indexes, param.default.startYear, param.default.endYear);

  if (!regression) return [0, 0, 0];

  var totalChange = regression.slope * regression.yearSpan;
  var clampedChange = Math.max(-param.linearRegression.pixelEvalMaxValue,
                               Math.min(param.linearRegression.pixelEvalMaxValue, totalChange));

  return valueInterpolate(
    clampedChange,
    [-param.linearRegression.pixelEvalMaxValue, 0, param.linearRegression.pixelEvalMaxValue],
    [[1, 0, 0], [1, 1, 1], [0, 1, 0]]
  );
}}

function valueInterpolate(val, inputRange, outputRange) {{
  if (val <= inputRange[0]) return outputRange[0];
  if (val >= inputRange[inputRange.length - 1]) return outputRange[outputRange.length - 1];

  for (var i = 0; i < inputRange.length - 1; i++) {{
    if (val >= inputRange[i] && val <= inputRange[i + 1]) {{
      var t = (val - inputRange[i]) / (inputRange[i + 1] - inputRange[i]);
      return [
        outputRange[i][0] + t * (outputRange[i + 1][0] - outputRange[i][0]),
        outputRange[i][1] + t * (outputRange[i + 1][1] - outputRange[i][1]),
        outputRange[i][2] + t * (outputRange[i + 1][2] - outputRange[i][2])
      ];
    }}
  }}
  return outputRange[0];
}}"""
}

# Encrypt each evalscript
encrypted_evalscripts = {}
for name, template in evalscripts.items():
    encrypted = fernet.encrypt(template.encode('utf-8'))
    encrypted_evalscripts[name] = base64.b64encode(encrypted).decode('utf-8')
    print(f"{name}: {len(encrypted)} bytes encrypted")

# Generate Python module
output = f'''# -*- coding: utf-8 -*-
"""
Encrypted Evalscript Templates for ForestLens QGIS Plugin

These evalscripts are encrypted to protect IP while allowing QGIS plugin
to generate them client-side (avoiding Vercel rate limits).

DO NOT MODIFY THIS FILE - Generated by scripts/encrypt_evalscripts.py
"""

# Encryption key (obfuscated)
ENCRYPTION_KEY = "{key.decode()}"

# Encrypted evalscript templates (Base64-encoded Fernet-encrypted)
ENCRYPTED_EVALSCRIPTS = {{
'''

for name, encrypted in encrypted_evalscripts.items():
    output += f'    "{name}": """{encrypted}""",\n'

output += "}\n"

# Write to file
with open("../core/evalscripts_encrypted.py", "w", encoding="utf-8") as f:
    f.write(output)

print("\nGenerated: core/evalscripts_encrypted.py")
print(f"Total evalscripts encrypted: {len(encrypted_evalscripts)}")
