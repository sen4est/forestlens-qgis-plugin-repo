# -*- coding: utf-8 -*-
"""
ForestLens QGIS Plugin - Main Dock Widget

Main analysis panel for running forest analyses from QGIS.
"""

import os
import tempfile
from pathlib import Path
from qgis.PyQt.QtWidgets import (
    QDockWidget,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QGridLayout,
    QLabel,
    QPushButton,
    QComboBox,
    QSpinBox,
    QDoubleSpinBox,
    QCheckBox,
    QGroupBox,
    QMessageBox,
    QProgressBar,
    QTextEdit,
    QScrollArea,
    QFrame,
    QLineEdit,
    QFileDialog
)
from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
from qgis.PyQt.QtGui import QFont
from qgis.core import (
    QgsProject,
    QgsVectorLayer,
    QgsFeature,
    QgsRasterLayer,
    QgsMessageLog,
    Qgis
)

from ..core.auth import ForestLensAuth
from ..core.api_client import ForestLensApiClient, AnalysisType, AnalysisConfig, AnalysisResult
from ..core.geometry_utils import qgis_geometry_to_geojson, qgis_features_to_geojson, validate_geometry
from ..core.constants import DEFAULT_CONFIG
from ..core.qml_generator import QMLGenerator
from .login_dialog import LoginDialog


class AnalysisWorker(QThread):
    """Background worker for running analyses."""

    progress = pyqtSignal(str)
    finished = pyqtSignal(object, object)  # AnalysisResult, AnalysisConfig
    error = pyqtSignal(str)

    def __init__(self, api_client, analysis_type, geometry, config, pro_mode=False):
        super().__init__()
        self.api_client = api_client
        self.analysis_type = analysis_type
        self.geometry = geometry
        self.config = config
        self.pro_mode = pro_mode

    def run(self):
        """Run analysis in background thread."""
        try:
            result = self.api_client.run_analysis(
                self.analysis_type,
                self.geometry,
                self.config,
                progress_callback=self.progress.emit,
                pro_mode=self.pro_mode
            )
            self.finished.emit(result, self.config)
        except Exception as e:
            self.error.emit(str(e))


class ForestLensDockWidget(QDockWidget):
    """
    Main dock widget for ForestLens analysis.

    Provides UI for selecting analysis type, configuring parameters,
    and running analyses on selected geometries.
    """

    def __init__(self, iface, auth_manager, parent=None):
        """
        Initialize dock widget.

        Args:
            iface: QGIS interface
            auth_manager: ForestLensAuth instance
            parent: Parent widget
        """
        super().__init__("ForestLens Analysis", parent)
        self.iface = iface
        self.auth_manager = auth_manager
        self.api_client = ForestLensApiClient(auth_manager)
        self.worker = None
        self.user_info = None

        self.setup_ui()
        self.check_login_status()

        # Connect to layer and selection change signals
        self.iface.layerTreeView().currentLayerChanged.connect(self.update_feature_selection_label_from_layer)
        # Note: We'll connect to selection changed signal per-layer basis

    def _log(self, message: str, level: Qgis.MessageLevel = Qgis.Info):
        """Log message to QGIS log panel."""
        QgsMessageLog.logMessage(message, 'ForestLens-UI', level)

    def setup_ui(self):
        """Setup the user interface."""
        # Create main widget and layout
        main_widget = QWidget()
        main_layout = QVBoxLayout()
        main_layout.setSpacing(10)

        # Create scroll area for the content
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll_content = QWidget()
        scroll_layout = QVBoxLayout()
        scroll_layout.setSpacing(10)

        # =====================================================================
        # USER STATUS SECTION
        # =====================================================================
        status_group = QGroupBox("User Status")
        status_layout = QVBoxLayout()

        self.status_label = QLabel("Not logged in")
        self.status_label.setStyleSheet("color: red; font-weight: bold;")
        status_layout.addWidget(self.status_label)

        self.login_button = QPushButton("Login")
        self.login_button.clicked.connect(self.show_login_dialog)
        status_layout.addWidget(self.login_button)

        self.logout_button = QPushButton("Logout")
        self.logout_button.clicked.connect(self.logout)
        self.logout_button.setVisible(False)
        status_layout.addWidget(self.logout_button)

        status_group.setLayout(status_layout)
        scroll_layout.addWidget(status_group)

        # =====================================================================
        # ANALYSIS TYPE SECTION
        # =====================================================================
        analysis_group = QGroupBox("Analysis Type")
        analysis_layout = QVBoxLayout()

        self.analysis_combo = QComboBox()
        self.analysis_combo.addItem("Linear Regression", AnalysisType.LINEAR_REGRESSION)
        self.analysis_combo.addItem("Theil-Sen Estimator", AnalysisType.THEIL_SEN)
        self.analysis_combo.addItem("NDVI Anomaly Detection", AnalysisType.NDVI_ANOMALY)
        self.analysis_combo.addItem("Forest Change Detector", AnalysisType.FOREST_CHANGE_DETECTOR)
        self.analysis_combo.currentIndexChanged.connect(self.on_analysis_type_changed)
        analysis_layout.addWidget(self.analysis_combo)

        self.analysis_description = QLabel()
        self.analysis_description.setWordWrap(True)
        self.analysis_description.setStyleSheet("color: gray; font-size: 9pt;")
        analysis_layout.addWidget(self.analysis_description)

        analysis_group.setLayout(analysis_layout)
        scroll_layout.addWidget(analysis_group)

        # =====================================================================
        # TIME PERIOD SECTION
        # =====================================================================
        time_group = QGroupBox("Time Period")
        time_layout = QVBoxLayout()

        # Start year
        start_year_layout = QHBoxLayout()
        start_year_layout.addWidget(QLabel("Start Year:"))
        self.start_year_spin = QSpinBox()
        self.start_year_spin.setRange(2015, 2025)
        self.start_year_spin.setValue(2017)
        start_year_layout.addWidget(self.start_year_spin)
        time_layout.addLayout(start_year_layout)

        # End year
        end_year_layout = QHBoxLayout()
        end_year_layout.addWidget(QLabel("End Year:"))
        self.end_year_spin = QSpinBox()
        self.end_year_spin.setRange(2015, 2025)
        self.end_year_spin.setValue(2025)
        end_year_layout.addWidget(self.end_year_spin)
        time_layout.addLayout(end_year_layout)

        time_group.setLayout(time_layout)
        scroll_layout.addWidget(time_group)

        # =====================================================================
        # PARAMETERS SECTION
        # =====================================================================
        params_group = QGroupBox("Parameters")
        params_layout = QVBoxLayout()

        # Max cloud coverage
        cloud_layout = QHBoxLayout()
        cloud_layout.addWidget(QLabel("Max Cloud Coverage (%):"))
        self.cloud_spin = QSpinBox()
        self.cloud_spin.setRange(0, 100)
        self.cloud_spin.setValue(DEFAULT_CONFIG['max_cloud_coverage'])
        cloud_layout.addWidget(self.cloud_spin)
        params_layout.addLayout(cloud_layout)

        # Target months selector
        months_label = QLabel("Target Months (for yearly averaging):")
        months_label.setStyleSheet("font-weight: bold; margin-top: 10px;")
        params_layout.addWidget(months_label)

        # Create grid of month checkboxes (4 columns x 3 rows)
        months_grid = QGridLayout()
        months_grid.setSpacing(5)

        self.month_checkboxes = []
        month_names = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']

        for i, month_name in enumerate(month_names):
            checkbox = QCheckBox(month_name)
            checkbox.setProperty('month_number', i + 1)  # Store 1-12
            # Set default checked months (6, 7, 8 = June, July, August)
            if (i + 1) in DEFAULT_CONFIG['target_months']:
                checkbox.setChecked(True)
            checkbox.toggled.connect(self.on_month_toggled)
            self.month_checkboxes.append(checkbox)

            row = i // 4
            col = i % 4
            months_grid.addWidget(checkbox, row, col)

        params_layout.addLayout(months_grid)

        # Selected months summary label
        self.selected_months_label = QLabel()
        self.selected_months_label.setStyleSheet("color: gray; font-size: 9pt; margin-top: 5px;")
        self.selected_months_label.setWordWrap(True)
        params_layout.addWidget(self.selected_months_label)
        self.update_selected_months_label()  # Initialize label text

        # Color scale section (hidden for Forest Change Detector)
        self.color_scale_widget = QWidget()
        color_scale_layout = QVBoxLayout()
        color_scale_layout.setContentsMargins(0, 0, 0, 0)

        color_scale_label = QLabel("Color Scale Range (for visualization):")
        color_scale_label.setStyleSheet("font-weight: bold; margin-top: 10px;")
        color_scale_layout.addWidget(color_scale_label)

        # Color scale min
        color_min_layout = QHBoxLayout()
        color_min_layout.addWidget(QLabel("  Min Value:"))
        self.color_scale_min_spin = QDoubleSpinBox()
        self.color_scale_min_spin.setRange(-1.0, 1.0)
        self.color_scale_min_spin.setSingleStep(0.01)
        self.color_scale_min_spin.setDecimals(3)
        self.color_scale_min_spin.setValue(-0.05)
        color_min_layout.addWidget(self.color_scale_min_spin)
        color_scale_layout.addLayout(color_min_layout)

        # Color scale max
        color_max_layout = QHBoxLayout()
        color_max_layout.addWidget(QLabel("  Max Value:"))
        self.color_scale_max_spin = QDoubleSpinBox()
        self.color_scale_max_spin.setRange(-1.0, 1.0)
        self.color_scale_max_spin.setSingleStep(0.01)
        self.color_scale_max_spin.setDecimals(3)
        self.color_scale_max_spin.setValue(0.05)
        color_max_layout.addWidget(self.color_scale_max_spin)
        color_scale_layout.addLayout(color_max_layout)

        self.color_scale_widget.setLayout(color_scale_layout)
        params_layout.addWidget(self.color_scale_widget)

        # NDVI Anomaly specific parameters (only shown when NDVI Anomaly is selected)
        self.ndvi_anomaly_widget = QWidget()
        ndvi_anomaly_layout = QVBoxLayout()
        ndvi_anomaly_layout.setContentsMargins(0, 0, 0, 0)

        ndvi_anomaly_label = QLabel("NDVI Anomaly Options:")
        ndvi_anomaly_label.setStyleSheet("font-weight: bold; margin-top: 10px;")
        ndvi_anomaly_layout.addWidget(ndvi_anomaly_label)

        # Use Percentile Reference checkbox (combines usePercentile and useDoubleDifference)
        self.use_percentile_reference_check = QCheckBox('Use Percentile Reference (compare with "good years" instead of mean)')
        self.use_percentile_reference_check.setChecked(False)
        self.use_percentile_reference_check.setToolTip("Uses percentile baseline from historical data instead of mean value")
        self.use_percentile_reference_check.toggled.connect(self.on_use_percentile_reference_toggled)
        ndvi_anomaly_layout.addWidget(self.use_percentile_reference_check)

        # Percentile threshold
        percentile_layout = QHBoxLayout()
        percentile_layout.addWidget(QLabel("  Percentile Threshold:"))
        self.percentile_threshold_spin = QSpinBox()
        self.percentile_threshold_spin.setRange(0, 100)
        self.percentile_threshold_spin.setValue(75)
        self.percentile_threshold_spin.setSuffix("%")
        self.percentile_threshold_spin.setEnabled(False)
        percentile_layout.addWidget(self.percentile_threshold_spin)
        ndvi_anomaly_layout.addLayout(percentile_layout)

        self.ndvi_anomaly_widget.setLayout(ndvi_anomaly_layout)
        self.ndvi_anomaly_widget.setVisible(False)  # Hidden by default
        params_layout.addWidget(self.ndvi_anomaly_widget)

        params_group.setLayout(params_layout)
        scroll_layout.addWidget(params_group)

        # =====================================================================
        # GEOMETRY SOURCE SECTION
        # =====================================================================
        geom_group = QGroupBox("Geometry Source")
        geom_layout = QVBoxLayout()

        geom_info = QLabel("Select one or more polygon features from an active vector layer.")
        geom_info.setWordWrap(True)
        geom_info.setStyleSheet("color: gray; font-size: 9pt;")
        geom_layout.addWidget(geom_info)

        # Feature selection status label
        self.feature_selection_label = QLabel("No features selected")
        self.feature_selection_label.setStyleSheet("color: gray; font-size: 9pt; font-style: italic;")
        geom_layout.addWidget(self.feature_selection_label)

        self.draw_button = QPushButton("Draw Custom Polygon")
        self.draw_button.clicked.connect(self.start_drawing)
        self.draw_button.setEnabled(False)  # TODO: Implement drawing tool
        geom_layout.addWidget(self.draw_button)

        geom_group.setLayout(geom_layout)
        scroll_layout.addWidget(geom_group)

        # =====================================================================
        # OUTPUT DIRECTORY SECTION
        # =====================================================================
        output_group = QGroupBox("Output Directory")
        output_layout = QVBoxLayout()

        # Directory path field with browse button
        dir_selector_layout = QHBoxLayout()

        self.output_dir_input = QLineEdit()
        self.output_dir_input.setPlaceholderText("Default: Temporary directory")
        self.output_dir_input.setText(tempfile.gettempdir())
        self.output_dir_input.setReadOnly(True)
        dir_selector_layout.addWidget(self.output_dir_input)

        self.browse_dir_button = QPushButton("Browse...")
        self.browse_dir_button.clicked.connect(self.browse_output_directory)
        dir_selector_layout.addWidget(self.browse_dir_button)

        output_layout.addLayout(dir_selector_layout)

        # Info label
        output_info = QLabel("GeoTIFF files will be saved to this directory and loaded into QGIS.")
        output_info.setWordWrap(True)
        output_info.setStyleSheet("color: gray; font-size: 9pt;")
        output_layout.addWidget(output_info)

        output_group.setLayout(output_layout)
        scroll_layout.addWidget(output_group)

        # =====================================================================
        # RUN ANALYSIS SECTION
        # =====================================================================
        run_group = QGroupBox("Run Analysis")
        run_layout = QVBoxLayout()

        self.run_button = QPushButton("Run Analysis")
        self.run_button.clicked.connect(self.run_analysis)
        self.run_button.setEnabled(False)
        run_button_font = QFont()
        run_button_font.setBold(True)
        self.run_button.setFont(run_button_font)
        self.run_button.setMinimumHeight(40)
        run_layout.addWidget(self.run_button)

        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        self.progress_bar.setRange(0, 0)  # Indeterminate
        run_layout.addWidget(self.progress_bar)

        self.progress_label = QLabel()
        self.progress_label.setVisible(False)
        self.progress_label.setWordWrap(True)
        self.progress_label.setStyleSheet("font-size: 9pt;")
        run_layout.addWidget(self.progress_label)

        run_group.setLayout(run_layout)
        scroll_layout.addWidget(run_group)

        # Add stretch to push everything to top
        scroll_layout.addStretch()

        scroll_content.setLayout(scroll_layout)
        scroll.setWidget(scroll_content)
        main_layout.addWidget(scroll)

        main_widget.setLayout(main_layout)
        self.setWidget(main_widget)

        # Update description for default selection
        self.on_analysis_type_changed()

    def check_login_status(self):
        """Check and update login status."""
        if self.auth_manager.is_logged_in():
            # User is logged in - skip fetching user info to avoid rate limits
            email = self.auth_manager.get_user_email()
            if email:
                self.status_label.setText(f"Logged in as: {email}")
                self.status_label.setStyleSheet("color: green; font-weight: bold;")
                self.login_button.setVisible(False)
                self.logout_button.setVisible(True)
                self.run_button.setEnabled(True)
                self._log(f"Logged in as: {email}")
            else:
                # No user email - session actually expired
                self.status_label.setText("Session expired")
                self.status_label.setStyleSheet("color: red; font-weight: bold;")
                self.auth_manager.logout()
                self.login_button.setVisible(True)
                self.logout_button.setVisible(False)
                self.run_button.setEnabled(False)
        else:
            # Not logged in
            self.status_label.setText("Not logged in")
            self.status_label.setStyleSheet("color: red; font-weight: bold;")
            self.login_button.setVisible(True)
            self.logout_button.setVisible(False)
            self.run_button.setEnabled(False)

    def show_login_dialog(self):
        """Show login dialog."""
        dialog = LoginDialog(self.auth_manager, self)
        dialog.login_successful.connect(self.check_login_status)
        dialog.exec_()

    def logout(self):
        """Logout user."""
        reply = QMessageBox.question(
            self,
            "Logout",
            "Are you sure you want to logout?",
            QMessageBox.Yes | QMessageBox.No
        )

        if reply == QMessageBox.Yes:
            self.auth_manager.logout()
            self.user_info = None
            self.check_login_status()
            QMessageBox.information(self, "Logged Out", "You have been logged out successfully.")

    def on_analysis_type_changed(self):
        """Update description and show/hide parameters based on analysis type."""
        analysis_type = self.analysis_combo.currentData()

        descriptions = {
            AnalysisType.LINEAR_REGRESSION: "Fits linear regression through yearly NDVI averages to detect long-term vegetation trends.",
            AnalysisType.THEIL_SEN: "Robust trend estimation resistant to outliers. Uses median of pairwise slopes.",
            AnalysisType.NDVI_ANOMALY: "Detects vegetation anomalies by comparing current year to historical baseline.",
            AnalysisType.FOREST_CHANGE_DETECTOR: "Advanced 19-category classification of forest dynamics: degradation, stagnation, growth, stress, and regeneration patterns."
        }

        self.analysis_description.setText(descriptions.get(analysis_type, ""))

        # Show/hide parameters and set default color ranges based on analysis type
        if analysis_type == AnalysisType.FOREST_CHANGE_DETECTOR:
            # Forest Change Detector: Hide color scale controls (categorical data)
            self.color_scale_widget.setVisible(False)
            self.ndvi_anomaly_widget.setVisible(False)
        elif analysis_type == AnalysisType.NDVI_ANOMALY:
            # NDVI Anomaly: Show both color scale and NDVI Anomaly controls
            self.color_scale_widget.setVisible(True)
            self.ndvi_anomaly_widget.setVisible(True)
            # Set NDVI Anomaly default color range: ±0.3
            self.color_scale_min_spin.setValue(-0.3)
            self.color_scale_max_spin.setValue(0.3)
        else:
            # Linear Regression / Theil-Sen: Show color scale, hide NDVI Anomaly controls
            self.color_scale_widget.setVisible(True)
            self.ndvi_anomaly_widget.setVisible(False)
            # Set Linear Regression / Theil-Sen default color range: ±0.05
            self.color_scale_min_spin.setValue(-0.05)
            self.color_scale_max_spin.setValue(0.05)

    def on_use_percentile_reference_toggled(self, checked: bool):
        """Handle use percentile reference checkbox toggle."""
        self.percentile_threshold_spin.setEnabled(checked)

    def on_month_toggled(self):
        """Handle month checkbox toggle."""
        self.update_selected_months_label()

    def update_selected_months_label(self):
        """Update the selected months summary label."""
        selected_months = self.get_selected_months()
        if not selected_months:
            self.selected_months_label.setText("⚠ No months selected - please select at least one month")
            self.selected_months_label.setStyleSheet("color: red; font-size: 9pt; margin-top: 5px;")
        else:
            month_names = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
            selected_names = [month_names[m - 1] for m in selected_months]
            self.selected_months_label.setText(f"Selected: {', '.join(selected_names)}")
            self.selected_months_label.setStyleSheet("color: gray; font-size: 9pt; margin-top: 5px;")

    def get_selected_months(self):
        """Get list of selected month numbers (1-12)."""
        selected = []
        for checkbox in self.month_checkboxes:
            if checkbox.isChecked():
                selected.append(checkbox.property('month_number'))
        return sorted(selected)

    def browse_output_directory(self):
        """Open directory browser for output directory selection."""
        current_dir = self.output_dir_input.text() or tempfile.gettempdir()

        directory = QFileDialog.getExistingDirectory(
            self,
            "Select Output Directory",
            current_dir,
            QFileDialog.ShowDirsOnly | QFileDialog.DontResolveSymlinks
        )

        if directory:
            self.output_dir_input.setText(directory)
            self._log(f"Output directory set to: {directory}")

    def update_feature_selection_label_from_layer(self, layer=None):
        """Update feature selection label based on current layer."""
        if layer is None:
            layer = self.iface.activeLayer()

        # Disconnect previous layer's selection changed signal if any
        try:
            if hasattr(self, '_current_layer') and self._current_layer:
                self._current_layer.selectionChanged.disconnect(self.update_feature_selection_count)
        except:
            pass

        self._current_layer = layer

        if layer and isinstance(layer, QgsVectorLayer):
            # Connect to selection changed signal for this layer
            layer.selectionChanged.connect(self.update_feature_selection_count)
            # Update count immediately
            self.update_feature_selection_count()
        else:
            # No valid layer selected
            self.feature_selection_label.setText("No vector layer active")
            self.feature_selection_label.setStyleSheet("color: gray; font-size: 9pt; font-style: italic;")

    def update_feature_selection_count(self):
        """Update the feature selection count label."""
        layer = self.iface.activeLayer()

        if not layer or not isinstance(layer, QgsVectorLayer):
            self.feature_selection_label.setText("No vector layer active")
            self.feature_selection_label.setStyleSheet("color: gray; font-size: 9pt; font-style: italic;")
            return

        selected_features = layer.selectedFeatures()
        feature_count = len(selected_features)

        if feature_count == 0:
            self.feature_selection_label.setText("No features selected")
            self.feature_selection_label.setStyleSheet("color: gray; font-size: 9pt; font-style: italic;")
        elif feature_count == 1:
            self.feature_selection_label.setText("1 feature selected")
            self.feature_selection_label.setStyleSheet("color: green; font-size: 9pt; font-weight: bold;")
        else:
            self.feature_selection_label.setText(f"{feature_count} features selected (MultiPolygon)")
            self.feature_selection_label.setStyleSheet("color: green; font-size: 9pt; font-weight: bold;")

    def start_drawing(self):
        """Start custom polygon drawing."""
        # TODO: Implement drawing tool
        QMessageBox.information(
            self,
            "Coming Soon",
            "Custom polygon drawing tool will be available in the next version.\n\n"
            "For now, please select a feature from an existing vector layer."
        )

    def run_analysis(self):
        """Run analysis on selected geometry."""
        # Check if logged in
        if not self.auth_manager.is_logged_in():
            QMessageBox.warning(self, "Not Logged In", "Please login first.")
            self.show_login_dialog()
            return

        # Get selected feature from active layer
        layer = self.iface.activeLayer()

        if not layer or not isinstance(layer, QgsVectorLayer):
            QMessageBox.warning(
                self,
                "No Layer Selected",
                "Please select a vector layer with polygon features."
            )
            return

        selected_features = layer.selectedFeatures()

        if not selected_features:
            QMessageBox.warning(
                self,
                "No Feature Selected",
                "Please select one or more polygon features to analyze."
            )
            return

        # Validate all selected features
        for feature in selected_features:
            geometry = feature.geometry()
            is_valid, error_msg = validate_geometry(geometry)
            if not is_valid:
                QMessageBox.warning(
                    self,
                    "Invalid Geometry",
                    f"One or more features have invalid geometry:\n{error_msg}"
                )
                return

        # Convert features to GeoJSON (handles both single and multiple features)
        geojson = qgis_features_to_geojson(selected_features, layer.crs())
        if not geojson:
            QMessageBox.critical(
                self,
                "Conversion Error",
                "Failed to convert features to GeoJSON."
            )
            return

        # Get analysis parameters
        analysis_type = self.analysis_combo.currentData()

        # Get selected months
        selected_months = self.get_selected_months()
        if not selected_months:
            QMessageBox.warning(
                self,
                "No Months Selected",
                "Please select at least one target month for yearly averaging."
            )
            return

        # Get color scale parameters from spin boxes
        # (defaults are automatically set based on analysis type in on_analysis_type_changed)
        color_scale_min = self.color_scale_min_spin.value()
        color_scale_max = self.color_scale_max_spin.value()

        # For NDVI Anomaly: "Use Percentile Reference" sets both usePercentile and useDoubleDifference
        use_percentile_reference = self.use_percentile_reference_check.isChecked()

        config = AnalysisConfig(
            start_year=self.start_year_spin.value(),
            end_year=self.end_year_spin.value(),
            target_months=selected_months,  # Use selected months from checkboxes
            max_cloud_coverage=self.cloud_spin.value(),
            pixel_eval_max_value=DEFAULT_CONFIG['pixel_eval_max_value'],
            use_double_difference=use_percentile_reference,  # Set to true when percentile reference is used
            use_percentile=use_percentile_reference,  # Set to true when percentile reference is used
            percentile_threshold=self.percentile_threshold_spin.value(),
            color_scale_min=color_scale_min,
            color_scale_max=color_scale_max
        )

        # Validate parameters
        if config.start_year >= config.end_year:
            QMessageBox.warning(
                self,
                "Invalid Time Period",
                "Start year must be before end year."
            )
            return

        # Confirm before running
        feature_count_text = f"{len(selected_features)} feature" if len(selected_features) == 1 else f"{len(selected_features)} features"
        reply = QMessageBox.question(
            self,
            "Confirm Analysis",
            f"Run {self.analysis_combo.currentText()} analysis for {config.start_year}-{config.end_year}?\n\n"
            f"Selected: {feature_count_text}\n"
            f"This may take several minutes depending on the area size.",
            QMessageBox.Yes | QMessageBox.No
        )

        if reply != QMessageBox.Yes:
            return

        # Start analysis in background
        self.run_button.setEnabled(False)
        self.progress_bar.setVisible(True)
        self.progress_label.setVisible(True)
        self.progress_label.setText("Starting analysis...")

        self.worker = AnalysisWorker(
            self.api_client,
            analysis_type,
            geojson,
            config,
            pro_mode=False
        )
        self.worker.progress.connect(self.on_progress)
        self.worker.finished.connect(self.on_analysis_finished)
        self.worker.error.connect(self.on_analysis_error)
        self.worker.start()

    def on_progress(self, message: str):
        """Handle progress updates."""
        self.progress_label.setText(message)
        self._log(f"Progress: {message}")

    def on_analysis_finished(self, result: AnalysisResult, config: AnalysisConfig):
        """Handle analysis completion."""
        self.progress_bar.setVisible(False)
        self.progress_label.setVisible(False)
        self.run_button.setEnabled(True)
        self.worker = None

        if result.success:
            # Save GeoTIFF to selected output directory
            try:
                # Get output directory from UI (defaults to temp if not set)
                output_dir = self.output_dir_input.text() or tempfile.gettempdir()

                # Create filename with timestamp to avoid conflicts
                from datetime import datetime
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                layer_name = f"ForestLens_{result.analysis_type}_{result.metadata.get('startYear', '')}_{result.metadata.get('endYear', '')}_{timestamp}"
                geotiff_filename = f"{layer_name}.tif"
                geotiff_path = os.path.join(output_dir, geotiff_filename)

                # Write GeoTIFF file
                with open(geotiff_path, 'wb') as f:
                    f.write(result.image_data)

                self._log(f"GeoTIFF saved to: {geotiff_path}")

                # Load as raster layer
                raster_layer = QgsRasterLayer(geotiff_path, layer_name)

                if raster_layer.isValid():
                    # Generate and apply QML style
                    try:
                        qml_content = QMLGenerator.generate_qml(
                            analysis_type=result.analysis_type,
                            min_value=config.color_scale_min,
                            max_value=config.color_scale_max
                        )

                        # Save QML to temporary file
                        with tempfile.NamedTemporaryFile(
                            mode='w',
                            suffix='.qml',
                            delete=False,
                            encoding='utf-8'
                        ) as qml_file:
                            qml_file.write(qml_content)
                            qml_path = qml_file.name

                        # Load QML style
                        raster_layer.loadNamedStyle(qml_path)
                        raster_layer.triggerRepaint()

                        # Clean up QML file
                        os.unlink(qml_path)

                        self._log(f"Applied {result.analysis_type} QML style")
                    except Exception as style_error:
                        self._log(f"Failed to apply style: {str(style_error)}", Qgis.Warning)

                    # Add layer to project
                    QgsProject.instance().addMapLayer(raster_layer)

                    QMessageBox.information(
                        self,
                        "Analysis Complete",
                        f"Analysis completed successfully!\n\n"
                        f"Layer '{layer_name}' has been added to the project.\n\n"
                        f"File saved to:\n{geotiff_path}"
                    )

                    self._log(f"Analysis complete: {layer_name}")
                else:
                    QMessageBox.critical(
                        self,
                        "Error Loading Result",
                        "Analysis completed but failed to load the result as a raster layer."
                    )
            except Exception as e:
                QMessageBox.critical(
                    self,
                    "Error Saving Result",
                    f"Failed to save analysis result: {str(e)}"
                )
                self._log(f"Error saving result: {str(e)}", Qgis.Critical)
        else:
            # Analysis failed
            QMessageBox.warning(
                self,
                "Analysis Failed",
                f"Analysis failed: {result.error}\n\n"
                f"Error code: {result.error_code}"
            )
            self._log(f"Analysis failed: {result.error} ({result.error_code})", Qgis.Warning)

    def on_analysis_error(self, error: str):
        """Handle analysis error."""
        self.progress_bar.setVisible(False)
        self.progress_label.setVisible(False)
        self.run_button.setEnabled(True)
        self.worker = None

        QMessageBox.critical(
            self,
            "Analysis Error",
            f"An unexpected error occurred:\n\n{error}"
        )
        self._log(f"Analysis error: {error}", Qgis.Critical)
