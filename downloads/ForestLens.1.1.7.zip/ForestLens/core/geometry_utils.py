# -*- coding: utf-8 -*-
"""
ForestLens QGIS Plugin - Geometry Utilities

Handles conversion between QGIS geometries and GeoJSON format.
"""

import json
from typing import Dict, Optional
from qgis.core import (
    QgsGeometry,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsProject,
    QgsWkbTypes,
    QgsMessageLog,
    Qgis
)


def qgis_geometry_to_geojson(
    geometry: QgsGeometry,
    source_crs: QgsCoordinateReferenceSystem
) -> Optional[Dict]:
    """
    Convert QGIS geometry to GeoJSON format.

    Args:
        geometry: QGIS geometry object
        source_crs: Source CRS of the geometry

    Returns:
        GeoJSON geometry dict, or None if conversion failed
    """
    try:
        # Transform to WGS84 (EPSG:4326) if needed
        target_crs = QgsCoordinateReferenceSystem("EPSG:4326")

        if source_crs != target_crs:
            transform = QgsCoordinateTransform(
                source_crs,
                target_crs,
                QgsProject.instance()
            )
            geometry = QgsGeometry(geometry)  # Make a copy
            geometry.transform(transform)

        # Export to GeoJSON
        geojson_str = geometry.asJson()
        geojson_dict = json.loads(geojson_str)

        return geojson_dict

    except Exception as e:
        QgsMessageLog.logMessage(
            f"Failed to convert geometry to GeoJSON: {str(e)}",
            'ForestLens-Geometry',
            Qgis.Warning
        )
        return None


def validate_geometry(geometry: QgsGeometry) -> tuple[bool, str]:
    """
    Validate geometry for analysis.

    Args:
        geometry: QGIS geometry to validate

    Returns:
        Tuple of (is_valid, error_message)
    """
    if geometry.isEmpty():
        return False, "Geometry is empty"

    if not geometry.isGeosValid():
        return False, "Geometry is not valid (topology issues)"

    geom_type = geometry.type()
    wkb_type = geometry.wkbType()

    # Check if it's a polygon or multipolygon
    if geom_type != QgsWkbTypes.PolygonGeometry:
        return False, "Only polygon geometries are supported"

    # Check geometry complexity (rough estimate)
    vertex_count = 0
    if wkb_type == QgsWkbTypes.Polygon:
        for ring in geometry.asPolygon():
            vertex_count += len(ring)
    elif wkb_type == QgsWkbTypes.MultiPolygon:
        for polygon in geometry.asMultiPolygon():
            for ring in polygon:
                vertex_count += len(ring)

    if vertex_count > 10000:
        return False, f"Geometry too complex ({vertex_count} vertices). Maximum is 10,000. Please simplify the geometry."

    # Check area (approximate)
    try:
        # Transform to a projected CRS for area calculation
        temp_geom = QgsGeometry(geometry)
        source_crs = QgsCoordinateReferenceSystem("EPSG:4326")
        target_crs = QgsCoordinateReferenceSystem("EPSG:3857")  # Web Mercator

        transform = QgsCoordinateTransform(
            source_crs,
            target_crs,
            QgsProject.instance()
        )
        temp_geom.transform(transform)

        area_sq_m = temp_geom.area()
        area_sq_km = area_sq_m / 1_000_000

        if area_sq_km > 1000:
            return False, f"Area too large ({area_sq_km:.1f} km²). Maximum is 1000 km²."

    except Exception as e:
        QgsMessageLog.logMessage(
            f"Warning: Could not calculate area: {str(e)}",
            'ForestLens-Geometry',
            Qgis.Warning
        )

    return True, ""


def simplify_geometry_if_needed(
    geometry: QgsGeometry,
    max_vertices: int = 10000
) -> QgsGeometry:
    """
    Simplify geometry if it exceeds the vertex limit.

    Args:
        geometry: QGIS geometry to simplify
        max_vertices: Maximum number of vertices

    Returns:
        Simplified geometry (or original if already simple enough)
    """
    vertex_count = geometry.constGet().nCoordinates()

    if vertex_count <= max_vertices:
        return geometry

    # Calculate tolerance for simplification
    # Start with a small tolerance and increase if needed
    bbox = geometry.boundingBox()
    tolerance = min(bbox.width(), bbox.height()) * 0.001

    simplified = geometry.simplify(tolerance)

    # Check if simplification was enough
    new_vertex_count = simplified.constGet().nCoordinates()

    if new_vertex_count > max_vertices:
        # Need more aggressive simplification
        tolerance = min(bbox.width(), bbox.height()) * 0.01
        simplified = geometry.simplify(tolerance)

    QgsMessageLog.logMessage(
        f"Simplified geometry from {vertex_count} to {simplified.constGet().nCoordinates()} vertices",
        'ForestLens-Geometry',
        Qgis.Info
    )

    return simplified


def qgis_features_to_multipolygon(
    features: list,
    source_crs: QgsCoordinateReferenceSystem
) -> Optional[Dict]:
    """
    Convert multiple QGIS features to a single GeoJSON MultiPolygon.

    This function handles multiple selected features and merges them into
    a single MultiPolygon geometry. For adjacent parcels, it applies a small
    negative buffer to create gaps and prevent "self-intersecting rings" errors.

    Args:
        features: List of QgsFeature objects
        source_crs: Source CRS of the features

    Returns:
        GeoJSON geometry dict (Polygon or MultiPolygon), or None if conversion failed
    """
    if not features:
        QgsMessageLog.logMessage(
            "Cannot create MultiPolygon from empty features list",
            'ForestLens-Geometry',
            Qgis.Warning
        )
        return None

    # Single feature: return as-is (Polygon)
    if len(features) == 1:
        return qgis_geometry_to_geojson(features[0].geometry(), source_crs)

    # Multiple features: create MultiPolygon with buffering
    try:
        target_crs = QgsCoordinateReferenceSystem("EPSG:4326")
        transform = None

        if source_crs != target_crs:
            transform = QgsCoordinateTransform(
                source_crs,
                target_crs,
                QgsProject.instance()
            )

        polygon_coordinates = []

        for feature in features:
            geometry = QgsGeometry(feature.geometry())  # Make a copy

            if geometry.isEmpty():
                QgsMessageLog.logMessage(
                    "Skipping feature without geometry",
                    'ForestLens-Geometry',
                    Qgis.Warning
                )
                continue

            # Transform to WGS84 first
            if transform:
                geometry.transform(transform)

            # Apply small negative buffer (-0.5 meters) to create gaps between adjacent parcels
            # This prevents "self-intersecting rings" errors when parcels share edges
            # Convert -0.5m to degrees (approximately 0.0000045 degrees at equator)
            buffer_distance_degrees = -0.0000045  # ~-0.5 meters
            buffered_geometry = geometry.buffer(buffer_distance_degrees, 5)

            # Extract coordinates from buffered geometry
            if buffered_geometry.isEmpty():
                # Buffer failed, use original geometry
                QgsMessageLog.logMessage(
                    "Buffer operation resulted in empty geometry, using original",
                    'ForestLens-Geometry',
                    Qgis.Warning
                )
                buffered_geometry = geometry

            # Convert to GeoJSON and extract coordinates
            geojson_str = buffered_geometry.asJson()
            geojson_dict = json.loads(geojson_str)

            if geojson_dict['type'] == 'Polygon':
                polygon_coordinates.append(geojson_dict['coordinates'])
            elif geojson_dict['type'] == 'MultiPolygon':
                # Flatten MultiPolygon coordinates
                for poly_coords in geojson_dict['coordinates']:
                    polygon_coordinates.append(poly_coords)

        if not polygon_coordinates:
            QgsMessageLog.logMessage(
                "No valid polygon geometries found in features",
                'ForestLens-Geometry',
                Qgis.Warning
            )
            return None

        # Return MultiPolygon with buffered polygons
        return {
            'type': 'MultiPolygon',
            'coordinates': polygon_coordinates
        }

    except Exception as e:
        QgsMessageLog.logMessage(
            f"Failed to create MultiPolygon from features: {str(e)}",
            'ForestLens-Geometry',
            Qgis.Warning
        )
        return None


def qgis_features_to_geojson(
    features: list,
    source_crs: QgsCoordinateReferenceSystem
) -> Optional[Dict]:
    """
    Convert QGIS features to GeoJSON format.

    Handles both single and multiple feature selections:
    - Single feature: returns Polygon geometry
    - Multiple features: returns MultiPolygon geometry with buffering

    Args:
        features: List of QgsFeature objects
        source_crs: Source CRS of the features

    Returns:
        GeoJSON geometry dict, or None if conversion failed

    Example:
        >>> features = layer.selectedFeatures()
        >>> geojson = qgis_features_to_geojson(features, layer.crs())
    """
    if not features:
        return None

    if len(features) == 1:
        return qgis_geometry_to_geojson(features[0].geometry(), source_crs)
    else:
        return qgis_features_to_multipolygon(features, source_crs)
