# -*- coding: utf-8 -*-
"""
ForestLens QGIS Plugin - QML Style Generator

Dynamic QML generation for raster visualization based on analysis type and user-defined color scales.
"""

from typing import Optional, Tuple


class QMLGenerator:
    """
    Generates QML style files for ForestLens analysis results.

    Creates QGIS raster styles with user-configurable color scales and
    analysis-specific color ramps.
    """

    # Color ramps for different analysis types (RGB tuples)
    COLOR_RAMPS = {
        'diverging_red_green': {
            'min_color': (215, 25, 28),      # Red (declining/negative)
            'mid_color': (255, 255, 255),     # White (neutral)
            'max_color': (26, 150, 65)        # Green (increasing/positive)
        },
        'categorical_forest': {
            # 19-category forest change detector colors
            # Will be defined as discrete categories
        }
    }

    @staticmethod
    def generate_linear_regression_qml(
        min_value: float = -0.05,
        max_value: float = 0.05
    ) -> str:
        """
        Generate QML for Linear Regression analysis.

        Args:
            min_value: Minimum value for color scale (declining trend)
            max_value: Maximum value for color scale (increasing trend)

        Returns:
            QML string
        """
        mid_value = (min_value + max_value) / 2
        colors = QMLGenerator.COLOR_RAMPS['diverging_red_green']

        return f"""<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.0" styleCategories="AllStyleCategories">
  <pipe-data-defined-properties>
    <Option type="Map">
      <Option name="name" value="" type="QString"/>
      <Option name="properties"/>
      <Option name="type" value="collection" type="QString"/>
    </Option>
  </pipe-data-defined-properties>
  <pipe>
    <provider>
      <resampling enabled="false" maxOversampling="2" zoomedInResamplingMethod="nearestNeighbour" zoomedOutResamplingMethod="nearestNeighbour"/>
    </provider>
    <rasterrenderer alphaBand="-1" band="1" classificationMax="{max_value}" classificationMin="{min_value}" opacity="1" type="singlebandpseudocolor" nodataColor="255,255,255,0">
      <rasterTransparency>
        <singleValuePixelList>
          <pixelListEntry min="-999" max="-999" percentTransparent="100"/>
        </singleValuePixelList>
      </rasterTransparency>
      <minMaxOrigin>
        <limits>MinMax</limits>
        <extent>WholeRaster</extent>
        <statAccuracy>Estimated</statAccuracy>
      </minMaxOrigin>
      <rastershader>
        <colorrampshader classificationMode="2" colorRampType="INTERPOLATED" labelPrecision="4" minimumValue="{min_value}" maximumValue="{max_value}" clip="0">
          <colorramp name="[source]" type="gradient">
            <Option type="Map">
              <Option name="color1" value="{colors['min_color'][0]},{colors['min_color'][1]},{colors['min_color'][2]},255" type="QString"/>
              <Option name="color2" value="{colors['max_color'][0]},{colors['max_color'][1]},{colors['max_color'][2]},255" type="QString"/>
              <Option name="discrete" value="0" type="QString"/>
              <Option name="rampType" value="gradient" type="QString"/>
              <Option name="stops" value="0.5;{colors['mid_color'][0]},{colors['mid_color'][1]},{colors['mid_color'][2]},255" type="QString"/>
            </Option>
            <prop k="color1" v="{colors['min_color'][0]},{colors['min_color'][1]},{colors['min_color'][2]},255"/>
            <prop k="color2" v="{colors['max_color'][0]},{colors['max_color'][1]},{colors['max_color'][2]},255"/>
            <prop k="discrete" v="0"/>
            <prop k="rampType" v="gradient"/>
            <prop k="stops" v="0.5;{colors['mid_color'][0]},{colors['mid_color'][1]},{colors['mid_color'][2]},255"/>
          </colorramp>
          <item alpha="255" color="#d7191c" label="{min_value:.4f} (Declining)" value="{min_value}"/>
          <item alpha="255" color="#fdae61" label="{min_value/2:.4f}" value="{min_value/2}"/>
          <item alpha="255" color="#ffffff" label="0.0000 (Stable)" value="{mid_value}"/>
          <item alpha="255" color="#a6d96a" label="{max_value/2:.4f}" value="{max_value/2}"/>
          <item alpha="255" color="#1a9641" label="{max_value:.4f} (Increasing)" value="{max_value}"/>
        </colorrampshader>
      </rastershader>
    </rasterrenderer>
    <brightnesscontrast brightness="0" contrast="0" gamma="1"/>
    <huesaturation colorizeBlue="128" colorizeGreen="128" colorizeOn="0" colorizeRed="255" colorizeStrength="100" grayscaleMode="0" saturation="0"/>
    <rasterresampler maxOversampling="2"/>
    <resamplingStage>resamplingFilter</resamplingStage>
  </pipe>
  <blendMode>0</blendMode>
</qgis>"""

    @staticmethod
    def generate_theil_sen_qml(
        min_value: float = -0.05,
        max_value: float = 0.05
    ) -> str:
        """
        Generate QML for Theil-Sen analysis (same color scheme as Linear Regression).

        Args:
            min_value: Minimum value for color scale
            max_value: Maximum value for color scale

        Returns:
            QML string
        """
        # Same color scheme as linear regression
        return QMLGenerator.generate_linear_regression_qml(min_value, max_value)

    @staticmethod
    def generate_ndvi_anomaly_qml(
        min_value: float = -0.3,
        max_value: float = 0.3
    ) -> str:
        """
        Generate QML for NDVI Anomaly analysis.

        Args:
            min_value: Minimum anomaly value (negative deviation)
            max_value: Maximum anomaly value (positive deviation)

        Returns:
            QML string
        """
        mid_value = (min_value + max_value) / 2
        colors = QMLGenerator.COLOR_RAMPS['diverging_red_green']

        return f"""<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.0" styleCategories="AllStyleCategories">
  <pipe-data-defined-properties>
    <Option type="Map">
      <Option name="name" value="" type="QString"/>
      <Option name="properties"/>
      <Option name="type" value="collection" type="QString"/>
    </Option>
  </pipe-data-defined-properties>
  <pipe>
    <provider>
      <resampling enabled="false" maxOversampling="2" zoomedInResamplingMethod="nearestNeighbour" zoomedOutResamplingMethod="nearestNeighbour"/>
    </provider>
    <rasterrenderer alphaBand="-1" band="1" classificationMax="{max_value}" classificationMin="{min_value}" opacity="1" type="singlebandpseudocolor" nodataColor="255,255,255,0">
      <rasterTransparency>
        <singleValuePixelList>
          <pixelListEntry min="-999" max="-999" percentTransparent="100"/>
        </singleValuePixelList>
      </rasterTransparency>
      <minMaxOrigin>
        <limits>MinMax</limits>
        <extent>WholeRaster</extent>
        <statAccuracy>Estimated</statAccuracy>
      </minMaxOrigin>
      <rastershader>
        <colorrampshader classificationMode="2" colorRampType="INTERPOLATED" labelPrecision="4" minimumValue="{min_value}" maximumValue="{max_value}" clip="0">
          <colorramp name="[source]" type="gradient">
            <Option type="Map">
              <Option name="color1" value="{colors['min_color'][0]},{colors['min_color'][1]},{colors['min_color'][2]},255" type="QString"/>
              <Option name="color2" value="{colors['max_color'][0]},{colors['max_color'][1]},{colors['max_color'][2]},255" type="QString"/>
              <Option name="discrete" value="0" type="QString"/>
              <Option name="rampType" value="gradient" type="QString"/>
              <Option name="stops" value="0.5;{colors['mid_color'][0]},{colors['mid_color'][1]},{colors['mid_color'][2]},255" type="QString"/>
            </Option>
            <prop k="color1" v="{colors['min_color'][0]},{colors['min_color'][1]},{colors['min_color'][2]},255"/>
            <prop k="color2" v="{colors['max_color'][0]},{colors['max_color'][1]},{colors['max_color'][2]},255"/>
            <prop k="discrete" v="0"/>
            <prop k="rampType" v="gradient"/>
            <prop k="stops" v="0.5;{colors['mid_color'][0]},{colors['mid_color'][1]},{colors['mid_color'][2]},255"/>
          </colorramp>
          <item alpha="255" color="#d7191c" label="{min_value:.4f} (Negative Anomaly)" value="{min_value}"/>
          <item alpha="255" color="#fdae61" label="{min_value/2:.4f}" value="{min_value/2}"/>
          <item alpha="255" color="#ffffff" label="0.0000 (Normal)" value="{mid_value}"/>
          <item alpha="255" color="#a6d96a" label="{max_value/2:.4f}" value="{max_value/2}"/>
          <item alpha="255" color="#1a9641" label="{max_value:.4f} (Positive Anomaly)" value="{max_value}"/>
        </colorrampshader>
      </rastershader>
    </rasterrenderer>
    <brightnesscontrast brightness="0" contrast="0" gamma="1"/>
    <huesaturation colorizeBlue="128" colorizeGreen="128" colorizeOn="0" colorizeRed="255" colorizeStrength="100" grayscaleMode="0" saturation="0"/>
    <rasterresampler maxOversampling="2"/>
    <resamplingStage>resamplingFilter</resamplingStage>
  </pipe>
  <blendMode>0</blendMode>
</qgis>"""

    @staticmethod
    def generate_forest_change_detector_qml() -> str:
        """
        Generate QML for Forest Change Detector (19 discrete categories).
        Uses the exact same color palette as the web app.

        Returns:
            QML string
        """
        # Category definitions with colors - EXACT MATCH FROM WEB APP
        # Source: components/map/ForestChangeDetectorLegend.tsx
        # Note: NoData (0) is set to transparent and blank label
        categories = [
            # Group I: DEGRADATION (Negative Trend / Negative Anomaly)
            (1, (51, 0, 0), "Critical Degradation"),       # #330000
            (2, (179, 0, 0), "Strong Decline"),             # #b30000
            (3, (255, 51, 51), "Moderate Decline"),         # #ff3333
            # Group II: STAGNATION (No Trend)
            (4, (255, 153, 0), "Slow Decline"),             # #ff9900
            (5, (255, 204, 102), "Negative Stagnation"),    # #ffcc66
            (6, (204, 255, 204), "Neutral"),                # #ccffcc
            (7, (102, 230, 179), "Beginning Improvement"),  # #66e6b3
            (8, (51, 204, 153), "Significant Improvement"), # #33cc99
            # Group III: GROWTH (Positive Trend / Positive Anomaly)
            (9, (0, 179, 77), "Moderate Growth"),           # #00b34d
            (10, (0, 128, 0), "Strong Vitality"),           # #008000
            (11, (0, 77, 0), "Expansion"),                  # #004d00
            # Group IV: STRESS (Positive Trend / Negative Anomaly)
            (12, (102, 0, 102), "Collapse"),                # #660066
            (13, (153, 0, 204), "Severe Setback"),          # #9900cc
            (14, (255, 0, 255), "Warning"),                 # #ff00ff
            (15, (230, 153, 230), "Stall"),                 # #e699e6
            # Group V: REGENERATION (Negative Trend / Positive Anomaly)
            (16, (217, 255, 102), "Mild Correction"),       # #d9ff66
            (17, (204, 255, 0), "Correction"),              # #ccff00
            (18, (255, 255, 51), "Beginning Recovery"),     # #ffff33
            (19, (255, 252, 178), "Strong Recovery")        # #fffcb2 (without alpha)
        ]

        # Build category items
        category_items = []
        # Add NoData as transparent with blank label
        category_items.append(
            f'          <item alpha="0" color="#000000" label="" value="0"/>'
        )
        # Add all other categories
        for value, (r, g, b), label in categories:
            hex_color = f"#{r:02x}{g:02x}{b:02x}"
            category_items.append(
                f'          <item alpha="255" color="{hex_color}" label="{value} - {label}" value="{value}"/>'
            )

        categories_str = "\n".join(category_items)

        return f"""<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.0" styleCategories="AllStyleCategories">
  <pipe-data-defined-properties>
    <Option type="Map">
      <Option name="name" value="" type="QString"/>
      <Option name="properties"/>
      <Option name="type" value="collection" type="QString"/>
    </Option>
  </pipe-data-defined-properties>
  <pipe>
    <provider>
      <resampling enabled="false" maxOversampling="2" zoomedInResamplingMethod="nearestNeighbour" zoomedOutResamplingMethod="nearestNeighbour"/>
    </provider>
    <rasterrenderer alphaBand="-1" band="1" classificationMax="19" classificationMin="0" opacity="1" type="singlebandpseudocolor">
      <rasterTransparency/>
      <minMaxOrigin>
        <limits>None</limits>
        <extent>WholeRaster</extent>
        <statAccuracy>Exact</statAccuracy>
      </minMaxOrigin>
      <rastershader>
        <colorrampshader classificationMode="1" colorRampType="EXACT" labelPrecision="0" minimumValue="0" maximumValue="19" clip="0">
{categories_str}
        </colorrampshader>
      </rastershader>
    </rasterrenderer>
    <brightnesscontrast brightness="0" contrast="0" gamma="1"/>
    <huesaturation colorizeBlue="128" colorizeGreen="128" colorizeOn="0" colorizeRed="255" colorizeStrength="100" grayscaleMode="0" saturation="0"/>
    <rasterresampler maxOversampling="2"/>
    <resamplingStage>resamplingFilter</resamplingStage>
  </pipe>
  <blendMode>0</blendMode>
</qgis>"""

    @staticmethod
    def generate_qml(
        analysis_type: str,
        min_value: Optional[float] = None,
        max_value: Optional[float] = None
    ) -> str:
        """
        Generate QML for any analysis type with automatic defaults.

        Args:
            analysis_type: Type of analysis ('linear_regression', 'theil_sen', 'ndvi_anomaly', 'forest_change_detector')
            min_value: Minimum value for color scale (None for auto-detect)
            max_value: Maximum value for color scale (None for auto-detect)

        Returns:
            QML string

        Raises:
            ValueError: If analysis_type is unknown
        """
        # Default values for each analysis type (matches web app defaults)
        defaults = {
            'linear_regression': (-0.05, 0.05),  # Web app: pixelEvalMaxValue: 0.05
            'theil_sen': (-0.05, 0.05),          # Web app: pixelEvalMaxValue: 0.05
            'ndvi_anomaly': (-0.3, 0.3),         # Web app: pixelEvalMaxValue: 0.3
            'forest_change_detector': (0, 19)    # Not used, categorical
        }

        if analysis_type not in defaults:
            raise ValueError(f"Unknown analysis type: {analysis_type}")

        # Use defaults if not specified
        if min_value is None or max_value is None:
            default_min, default_max = defaults[analysis_type]
            min_value = min_value if min_value is not None else default_min
            max_value = max_value if max_value is not None else default_max

        # Generate QML based on type
        if analysis_type == 'linear_regression':
            return QMLGenerator.generate_linear_regression_qml(min_value, max_value)
        elif analysis_type == 'theil_sen':
            return QMLGenerator.generate_theil_sen_qml(min_value, max_value)
        elif analysis_type == 'ndvi_anomaly':
            return QMLGenerator.generate_ndvi_anomaly_qml(min_value, max_value)
        elif analysis_type == 'forest_change_detector':
            return QMLGenerator.generate_forest_change_detector_qml()
        else:
            raise ValueError(f"Unknown analysis type: {analysis_type}")
