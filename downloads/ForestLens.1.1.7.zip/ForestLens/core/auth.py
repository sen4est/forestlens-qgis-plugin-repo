# -*- coding: utf-8 -*-
"""
ForestLens QGIS Plugin - Authentication Module

Handles authentication with ForestLens via Supabase.
Manages login, logout, token refresh, and session persistence.
"""

import time
import requests
from typing import Optional, Tuple
from qgis.core import QgsMessageLog, Qgis

from .secure_storage import SecureStorage, StoredCredentials
from .constants import (
    SUPABASE_URL,
    SUPABASE_ANON_KEY,
    TIMEOUT_AUTH,
    SESSION_IDLE_TIMEOUT_SECONDS,
    TOKEN_REFRESH_BUFFER_SECONDS
)


class ForestLensAuth:
    """
    Handle ForestLens authentication via Supabase.

    Manages login, logout, token refresh, and session persistence
    with secure storage and idle timeout.
    """

    def __init__(self):
        """Initialize authentication manager."""
        self._storage = SecureStorage()
        self._credentials: Optional[StoredCredentials] = None
        self._load_session()

    def _log(self, message: str, level: Qgis.MessageLevel = Qgis.Info):
        """Log message to QGIS log panel."""
        QgsMessageLog.logMessage(message, 'ForestLens-Auth', level)

    def _load_session(self):
        """Load saved session from secure storage."""
        self._credentials = self._storage.get_credentials()
        if self._credentials:
            if self._is_expired():
                self._log("Session expired, logging out")
                self.logout()
            else:
                self._log(f"Loaded session for {self._credentials.user_email}")

    def _is_expired(self) -> bool:
        """
        Check if session is expired due to idle timeout.

        Returns:
            bool: True if expired, False otherwise
        """
        if not self._credentials:
            return True

        idle_time = int(time.time()) - self._credentials.last_activity
        return idle_time > SESSION_IDLE_TIMEOUT_SECONDS

    def login(self, email: str, password: str) -> Tuple[bool, str]:
        """
        Login with ForestLens credentials.

        Args:
            email: User email address
            password: User password

        Returns:
            Tuple of (success, message)
        """
        try:
            self._log(f"Attempting login for {email}")

            response = requests.post(
                f"{SUPABASE_URL}/auth/v1/token?grant_type=password",
                headers={
                    "apikey": SUPABASE_ANON_KEY,
                    "Content-Type": "application/json"
                },
                json={
                    "email": email,
                    "password": password
                },
                timeout=TIMEOUT_AUTH
            )

            if response.status_code == 200:
                data = response.json()
                now = int(time.time())

                # Supabase returns expires_in (seconds), not expires_at (timestamp)
                expires_in = data.get("expires_in", 3600)
                expires_at = now + expires_in

                self._credentials = StoredCredentials(
                    access_token=data["access_token"],
                    refresh_token=data["refresh_token"],
                    user_email=data["user"]["email"],
                    user_id=data["user"]["id"],
                    expires_at=expires_at,
                    last_activity=now
                )

                # Try to store credentials (may fail if keyring not available)
                stored = self._storage.store_credentials(self._credentials)

                self._log(f"Login successful for {self._credentials.user_email} (stored: {stored})")
                return True, f"Logged in as {self._credentials.user_email}"

            elif response.status_code == 400:
                error_data = response.json()
                error_msg = error_data.get("error_description", "Invalid credentials")
                self._log(f"Login failed: {error_msg}", Qgis.Warning)
                return False, error_msg

            else:
                self._log(f"Login failed: HTTP {response.status_code}", Qgis.Warning)
                return False, f"Login failed: HTTP {response.status_code}"

        except requests.exceptions.Timeout:
            self._log("Login timeout", Qgis.Warning)
            return False, "Connection timeout. Please check your internet connection."

        except requests.exceptions.RequestException as e:
            self._log(f"Login error: {str(e)}", Qgis.Warning)
            return False, f"Connection error: {str(e)}"

        except Exception as e:
            self._log(f"Unexpected login error: {str(e)}", Qgis.Critical)
            return False, f"Unexpected error: {str(e)}"

    def logout(self):
        """Clear session and logout."""
        if self._credentials:
            self._log(f"Logging out {self._credentials.user_email}")
        self._storage.clear_credentials()
        self._credentials = None

    def is_logged_in(self) -> bool:
        """
        Check if user has a valid session.

        Returns:
            bool: True if logged in and session valid, False otherwise
        """
        if not self._credentials or self._is_expired():
            if self._credentials:
                self._log("Session expired")
            self.logout()
            return False
        return True

    def get_auth_header(self) -> dict:
        """
        Get Authorization header for API calls.
        Updates last activity timestamp.

        Returns:
            Dict with Authorization header

        Raises:
            RuntimeError: If not authenticated
        """
        if not self.is_logged_in():
            raise RuntimeError("Not authenticated")

        # Update last activity
        self._credentials.last_activity = int(time.time())

        # Try to store updated credentials (may fail if keyring not available, that's ok)
        if self._storage.is_available:
            self._storage.store_credentials(self._credentials)

        return {"Authorization": f"Bearer {self._credentials.access_token}"}

    def refresh_if_needed(self) -> bool:
        """
        Refresh token if expired or about to expire.

        Returns:
            bool: True if session is valid, False if refresh failed
        """
        if not self._credentials:
            return False

        # Check idle timeout
        if self._is_expired():
            self._log("Session expired due to inactivity")
            return False

        # Refresh if token expiring in next 5 minutes
        now = int(time.time())
        if now > (self._credentials.expires_at - TOKEN_REFRESH_BUFFER_SECONDS):
            self._log("Token expiring soon, refreshing...")
            return self._refresh_token()

        return True

    def _refresh_token(self) -> bool:
        """
        Refresh the access token.

        Returns:
            bool: True if successful, False otherwise
        """
        if not self._credentials:
            return False

        try:
            response = requests.post(
                f"{SUPABASE_URL}/auth/v1/token?grant_type=refresh_token",
                headers={
                    "apikey": SUPABASE_ANON_KEY,
                    "Content-Type": "application/json"
                },
                json={"refresh_token": self._credentials.refresh_token},
                timeout=TIMEOUT_AUTH
            )

            if response.status_code == 200:
                data = response.json()
                now = int(time.time())

                # Supabase returns expires_in (seconds), not expires_at (timestamp)
                expires_in = data.get("expires_in", 3600)
                expires_at = now + expires_in

                self._credentials.access_token = data["access_token"]
                self._credentials.refresh_token = data["refresh_token"]
                self._credentials.expires_at = expires_at

                # Try to store updated credentials (may fail if keyring not available)
                if self._storage.is_available:
                    self._storage.store_credentials(self._credentials)

                self._log("Token refreshed successfully")
                return True

            # Refresh failed
            self._log(f"Token refresh failed: HTTP {response.status_code}", Qgis.Warning)
            self.logout()
            return False

        except Exception as e:
            self._log(f"Token refresh error: {str(e)}", Qgis.Warning)
            return False

    def get_user_email(self) -> Optional[str]:
        """Get the logged-in user's email."""
        return self._credentials.user_email if self._credentials else None

    def get_user_id(self) -> Optional[str]:
        """Get the logged-in user's ID."""
        return self._credentials.user_id if self._credentials else None
