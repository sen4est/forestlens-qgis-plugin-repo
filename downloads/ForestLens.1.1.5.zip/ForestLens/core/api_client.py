# -*- coding: utf-8 -*-
"""
ForestLens QGIS Plugin - API Client

Client for communicating with ForestLens API endpoints.
All analysis requests go through ForestLens server (evalscripts stay server-side).
"""

import base64
import requests
import time
from dataclasses import dataclass
from typing import Optional, Dict, List, Callable, Any
from enum import Enum
from qgis.core import QgsMessageLog, Qgis, QgsSettings

from .auth import ForestLensAuth
from .constants import (
    FORESTLENS_API_URL,
    FORESTLENS_API_URL_DEV,
    TIMEOUT_ANALYSIS,
    TIMEOUT_AUTH,
    SETTINGS_GROUP
)


class AnalysisType(Enum):
    """Available analysis types."""
    LINEAR_REGRESSION = "linear_regression"
    THEIL_SEN = "theil_sen"
    NDVI_ANOMALY = "ndvi_anomaly"
    FOREST_CHANGE_DETECTOR = "forest_change_detector"


@dataclass
class AnalysisConfig:
    """Configuration for an analysis request."""
    start_year: int
    end_year: int
    target_months: List[int]
    max_cloud_coverage: int = 20
    pixel_eval_max_value: float = 0.02
    # NDVI Anomaly specific
    use_double_difference: bool = True
    use_percentile: bool = False
    percentile_threshold: int = 75
    # Color scale range (for QML styling)
    color_scale_min: Optional[float] = None  # Auto-detect if None
    color_scale_max: Optional[float] = None  # Auto-detect if None


@dataclass
class AnalysisResult:
    """Result of an analysis request."""
    success: bool
    image_data: Optional[bytes] = None  # Raw GeoTIFF bytes
    error: Optional[str] = None
    error_code: Optional[str] = None
    analysis_type: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


@dataclass
class UserInfo:
    """User information from API."""
    email: str
    user_id: str
    has_credentials: bool
    subscription_plan: str
    features: Dict[str, bool]


class ForestLensApiClient:
    """
    Client for ForestLens QGIS API endpoints.

    Handles communication with ForestLens server for analysis requests.
    """

    def __init__(self, auth: ForestLensAuth):
        """
        Initialize API client.

        Args:
            auth: ForestLensAuth instance for authentication
        """
        self.auth = auth
        self._base_url = self._get_base_url()

    def _log(self, message: str, level: Qgis.MessageLevel = Qgis.Info):
        """Log message to QGIS log panel."""
        QgsMessageLog.logMessage(message, 'ForestLens-API', level)

    def _get_base_url(self) -> str:
        """Get API base URL from settings."""
        settings = QgsSettings()
        settings.beginGroup(SETTINGS_GROUP)
        use_dev = settings.value('use_dev_server', False, type=bool)
        settings.endGroup()

        url = FORESTLENS_API_URL_DEV if use_dev else FORESTLENS_API_URL
        self._log(f"Using API URL: {url}")
        return url

    def get_user_info(self, max_retries: int = 3) -> Optional[UserInfo]:
        """
        Get user information and feature access with retry logic.

        Args:
            max_retries: Maximum number of retries for rate limit errors

        Returns:
            UserInfo if successful, None otherwise
        """
        for attempt in range(max_retries):
            try:
                if not self.auth.refresh_if_needed():
                    self._log("Session expired during refresh check", Qgis.Warning)
                    return None

                self._log(f"Fetching user info from {self._base_url}/api/qgis/user-info (attempt {attempt + 1}/{max_retries})")

                response = requests.get(
                    f"{self._base_url}/api/qgis/user-info",
                    headers=self.auth.get_auth_header(),
                    timeout=TIMEOUT_AUTH
                )

                self._log(f"User info response: HTTP {response.status_code}")

                if response.status_code == 200:
                    data = response.json()
                    self._log(f"User info data received successfully")

                    if data.get('success') and data.get('data'):
                        user_data = data['data']
                        return UserInfo(
                            email=user_data['email'],
                            user_id=user_data['userId'],
                            has_credentials=user_data['hasCredentials'],
                            subscription_plan=user_data['subscription']['plan'],
                            features=user_data['features']
                        )
                    else:
                        self._log(f"Invalid user info response structure: success={data.get('success')}, has_data={bool(data.get('data'))}", Qgis.Warning)
                        return None

                elif response.status_code == 429:
                    # Rate limited - retry with exponential backoff
                    if attempt < max_retries - 1:
                        wait_time = (2 ** attempt) * 5  # 5s, 10s, 20s (longer delays for Vercel rate limits)
                        self._log(f"Rate limited (429). Waiting {wait_time}s before retry...", Qgis.Warning)
                        time.sleep(wait_time)
                        continue  # Retry
                    else:
                        self._log(f"Rate limit exceeded after {max_retries} attempts", Qgis.Warning)
                        return None

                elif response.status_code == 401:
                    # Unauthorized - don't retry
                    self._log("Authentication failed (401) - session invalid", Qgis.Warning)
                    return None

                else:
                    self._log(f"Failed to get user info: HTTP {response.status_code}", Qgis.Warning)
                    try:
                        error_data = response.json()
                        self._log(f"Error response: {error_data}", Qgis.Warning)
                    except:
                        self._log(f"Response text: {response.text[:200]}", Qgis.Warning)
                    return None

            except Exception as e:
                self._log(f"Error getting user info: {str(e)}", Qgis.Critical)
                import traceback
                self._log(f"Traceback: {traceback.format_exc()}", Qgis.Critical)
                return None

        return None

    def run_analysis(
        self,
        analysis_type: AnalysisType,
        geometry: Dict,
        config: AnalysisConfig,
        progress_callback: Optional[Callable[[str], None]] = None,
        pro_mode: bool = False
    ) -> AnalysisResult:
        """
        Run analysis on server and get GeoTIFF result.

        Args:
            analysis_type: Type of analysis to run
            geometry: GeoJSON geometry dict
            config: Analysis configuration
            progress_callback: Optional callback for progress updates
            pro_mode: Whether to use pro mode (multi-band output)

        Returns:
            AnalysisResult with success status and data/error
        """
        if progress_callback:
            progress_callback("Preparing request...")

        # Refresh token if needed
        if not self.auth.refresh_if_needed():
            return AnalysisResult(
                success=False,
                error="Session expired. Please login again.",
                error_code="SESSION_EXPIRED"
            )

        # Build request payload
        payload = {
            "analysisType": analysis_type.value,
            "geometry": geometry,
            "config": {
                "startYear": config.start_year,
                "endYear": config.end_year,
                "targetMonths": config.target_months,
                "maxCloudCoverage": config.max_cloud_coverage,
                "pixelEvalMaxValue": config.pixel_eval_max_value,
            },
            "outputFormat": "geotiff",
            "crs": "EPSG:4326",
            "proMode": pro_mode
        }

        # Add NDVI Anomaly specific config
        if analysis_type == AnalysisType.NDVI_ANOMALY:
            payload["config"]["useDoubleDifference"] = config.use_double_difference
            payload["config"]["usePercentile"] = config.use_percentile
            payload["config"]["percentileThreshold"] = config.percentile_threshold

        try:
            if progress_callback:
                progress_callback("Sending request to Supabase...")

            self._log(f"Starting analysis: {analysis_type.value}")

            # Call Supabase Edge Function instead of Vercel (no rate limits!)
            from .constants import SUPABASE_URL

            response = requests.post(
                f"{SUPABASE_URL}/functions/v1/qgis-analysis",
                headers={
                    **self.auth.get_auth_header(),
                    "Content-Type": "application/json"
                },
                json=payload,
                timeout=TIMEOUT_ANALYSIS
            )

            if response.status_code == 200:
                data = response.json()

                if data.get("success") and data.get("data", {}).get("imageData"):
                    if progress_callback:
                        progress_callback("Decoding GeoTIFF...")

                    # Decode base64 GeoTIFF
                    image_data = base64.b64decode(data["data"]["imageData"])

                    self._log(f"Analysis successful, received {len(image_data)} bytes")

                    return AnalysisResult(
                        success=True,
                        image_data=image_data,
                        analysis_type=data["data"]["analysisType"],
                        metadata=data["data"].get("metadata")
                    )
                else:
                    error_msg = data.get("error", "Unknown error")
                    self._log(f"Analysis failed: {error_msg}", Qgis.Warning)
                    return AnalysisResult(
                        success=False,
                        error=error_msg,
                        error_code=data.get("code", "UNKNOWN_ERROR")
                    )

            elif response.status_code == 401:
                self._log("Authentication failed", Qgis.Warning)
                return AnalysisResult(
                    success=False,
                    error="Authentication failed. Please login again.",
                    error_code="AUTH_FAILED"
                )

            elif response.status_code == 429:
                self._log("Rate limit exceeded", Qgis.Warning)
                return AnalysisResult(
                    success=False,
                    error="Rate limit exceeded. Please try again later.",
                    error_code="RATE_LIMIT"
                )

            elif response.status_code == 400:
                error_data = response.json()
                error_msg = error_data.get("error", "Bad request")
                self._log(f"Bad request: {error_msg}", Qgis.Warning)
                return AnalysisResult(
                    success=False,
                    error=error_msg,
                    error_code=error_data.get("code", "BAD_REQUEST")
                )

            else:
                self._log(f"Server error: HTTP {response.status_code}", Qgis.Warning)
                return AnalysisResult(
                    success=False,
                    error=f"Server error: HTTP {response.status_code}",
                    error_code="SERVER_ERROR"
                )

        except requests.exceptions.Timeout:
            self._log("Request timeout", Qgis.Warning)
            return AnalysisResult(
                success=False,
                error="Request timeout. The analysis may take longer for large areas.",
                error_code="TIMEOUT"
            )

        except requests.exceptions.RequestException as e:
            self._log(f"Request error: {str(e)}", Qgis.Warning)
            return AnalysisResult(
                success=False,
                error=f"Network error: {str(e)}",
                error_code="NETWORK_ERROR"
            )

        except Exception as e:
            self._log(f"Unexpected error: {str(e)}", Qgis.Critical)
            return AnalysisResult(
                success=False,
                error=f"Unexpected error: {str(e)}",
                error_code="UNKNOWN_ERROR"
            )
