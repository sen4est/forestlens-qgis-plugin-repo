<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.0" styleCategories="AllStyleCategories">
  <pipe-data-defined-properties>
    <Option type="Map">
      <Option name="name" value="" type="QString"/>
      <Option name="properties"/>
      <Option name="type" value="collection" type="QString"/>
    </Option>
  </pipe-data-defined-properties>
  <pipe>
    <provider>
      <resampling enabled="false" maxOversampling="2" zoomedInResamplingMethod="nearestNeighbour" zoomedOutResamplingMethod="nearestNeighbour"/>
    </provider>
    <rasterrenderer alphaBand="-1" band="1" opacity="1" type="paletted">
      <rasterTransparency/>
      <minMaxOrigin>
        <limits>None</limits>
        <extent>WholeRaster</extent>
        <statAccuracy>Estimated</statAccuracy>
      </minMaxOrigin>
      <colorPalette>
        <!-- 19 Forest Change Categories -->
        <paletteEntry alpha="255" color="#8B0000" label="1: Severe Degradation" value="1"/>
        <paletteEntry alpha="255" color="#CD5C5C" label="2: Strong Degradation" value="2"/>
        <paletteEntry alpha="255" color="#F08080" label="3: Moderate Degradation" value="3"/>
        <paletteEntry alpha="255" color="#FFA07A" label="4: Slight Degradation" value="4"/>
        <paletteEntry alpha="255" color="#FFE4B5" label="5: Minor Decline" value="5"/>

        <paletteEntry alpha="255" color="#D3D3D3" label="6: Stable" value="6"/>
        <paletteEntry alpha="255" color="#A9A9A9" label="7: Stagnation" value="7"/>

        <paletteEntry alpha="255" color="#E6F5FF" label="8: Minor Recovery" value="8"/>
        <paletteEntry alpha="255" color="#B3E5FC" label="9: Slight Growth" value="9"/>
        <paletteEntry alpha="255" color="#81D4FA" label="10: Moderate Growth" value="10"/>
        <paletteEntry alpha="255" color="#4FC3F7" label="11: Strong Growth" value="11"/>
        <paletteEntry alpha="255" color="#29B6F6" label="12: Vigorous Growth" value="12"/>

        <paletteEntry alpha="255" color="#FFE082" label="13: Stress (Low)" value="13"/>
        <paletteEntry alpha="255" color="#FFD54F" label="14: Stress (Moderate)" value="14"/>
        <paletteEntry alpha="255" color="#FFCA28" label="15: Stress (High)" value="15"/>

        <paletteEntry alpha="255" color="#AED581" label="16: Early Regeneration" value="16"/>
        <paletteEntry alpha="255" color="#9CCC65" label="17: Active Regeneration" value="17"/>
        <paletteEntry alpha="255" color="#8BC34A" label="18: Strong Regeneration" value="18"/>
        <paletteEntry alpha="255" color="#689F38" label="19: Mature/Healthy" value="19"/>

        <paletteEntry alpha="0" color="#000000" label="No Data" value="0"/>
      </colorPalette>
    </rasterrenderer>
    <brightnesscontrast brightness="0" contrast="0" gamma="1"/>
    <huesaturation colorizeBlue="128" colorizeGreen="128" colorizeOn="0" colorizeRed="255" colorizeStrength="100" grayscaleMode="0" saturation="0"/>
    <rasterresampler maxOversampling="2"/>
    <resamplingStage>resamplingFilter</resamplingStage>
  </pipe>
  <blendMode>0</blendMode>
</qgis>
