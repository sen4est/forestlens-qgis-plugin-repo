# -*- coding: utf-8 -*-
"""
ForestLens QGIS Plugin - Main Plugin Class

This module contains the main plugin class that handles:
- Plugin initialization and cleanup
- Menu and toolbar integration
- Dock widget management
"""

import os
from qgis.PyQt.QtCore import Qt, QTranslator, QCoreApplication
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QMessageBox
from qgis.core import QgsApplication, QgsMessageLog, Qgis

from .core.auth import ForestLensAuth
from .core.secure_storage import SecureStorage
from .ui.unified_dockwidget import UnifiedForestLensDockWidget


class ForestLensPlugin:
    """
    ForestLens QGIS Plugin main class.

    Manages the plugin lifecycle and UI integration.
    """

    def __init__(self, iface):
        """
        Constructor.

        :param iface: An interface instance that provides access to QGIS
            application components.
        :type iface: QgsInterface
        """
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)

        # Initialize locale
        locale = QgsApplication.locale()
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            f'forestlens_{locale}.qm'
        )

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        # Plugin state
        self.actions = []
        self.menu_name = self.tr('&ForestLens')
        self.toolbar = None
        self.dock_widget = None  # Unified dock widget
        self.auth = None

        # First run flag
        self.first_start = True

    def tr(self, message):
        """
        Get the translation for a string using Qt translation API.
        """
        return QCoreApplication.translate('ForestLens', message)

    def _log(self, message: str, level: Qgis.MessageLevel = Qgis.Info):
        """Log message to QGIS log panel."""
        QgsMessageLog.logMessage(message, 'ForestLens', level)

    def _check_dependencies(self):
        """Check for optional dependencies."""
        try:
            import keyring
            self._log("Keyring module found - credentials will be saved securely")
        except ImportError:
            self._log("Keyring module not available - login required each session", Qgis.Info)

    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None
    ):
        """
        Add a toolbar icon to the plugin toolbar.

        :returns: The action that was created.
        :rtype: QAction
        """
        icon = QIcon(icon_path)
        action = QAction(icon, text, parent or self.iface.mainWindow())
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip:
            action.setStatusTip(status_tip)

        if whats_this:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            if not self.toolbar:
                self.toolbar = self.iface.addToolBar('ForestLens')
                self.toolbar.setObjectName('ForestLensToolbar')
            self.toolbar.addAction(action)

        if add_to_menu:
            self.iface.addPluginToMenu(self.menu_name, action)

        self.actions.append(action)
        return action

    def initGui(self):
        """
        Create the menu entries and toolbar icons inside the QGIS GUI.
        """
        # Check for required dependencies
        self._check_dependencies()

        # Check if secure storage is available (optional - just log it)
        storage = SecureStorage()
        if not storage.is_available:
            self._log("Keyring not available - you'll need to login each time you start QGIS", Qgis.Info)

        icon_path = os.path.join(self.plugin_dir, 'resources', 'icon.png')

        # Single main action for unified plugin
        self.add_action(
            icon_path,
            text=self.tr('ForestLens'),
            callback=self.show_dock_widget,
            parent=self.iface.mainWindow(),
            status_tip=self.tr('Open ForestLens analysis and Sentinel-2 browser')
        )

        # Help action
        self.add_action(
            icon_path,
            text=self.tr('Help'),
            callback=self.show_help,
            add_to_toolbar=False,
            parent=self.iface.mainWindow(),
            status_tip=self.tr('ForestLens documentation')
        )

        # Initialize auth manager
        self.auth = ForestLensAuth()
        self._log("ForestLens plugin initialized")

    def unload(self):
        """
        Removes the plugin menu item and icon from QGIS GUI.
        """
        for action in self.actions:
            self.iface.removePluginMenu(self.menu_name, action)
            self.iface.removeToolBarIcon(action)

        if self.toolbar:
            del self.toolbar

        if self.dock_widget:
            self.dock_widget.close()
            self.iface.removeDockWidget(self.dock_widget)
            self.dock_widget = None

        self._log("ForestLens plugin unloaded")

    def show_dock_widget(self):
        """
        Show the unified dock widget (creates it if necessary).
        """
        if not self.dock_widget:
            self.dock_widget = UnifiedForestLensDockWidget(
                self.iface,
                self.auth,
                parent=self.iface.mainWindow()
            )
            self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dock_widget)

        self.dock_widget.show()
        self.dock_widget.raise_()

    def show_help(self):
        """
        Show the help documentation.
        """
        import webbrowser
        help_url = 'https://forestlens.com/docs/qgis-plugin'
        webbrowser.open(help_url)
