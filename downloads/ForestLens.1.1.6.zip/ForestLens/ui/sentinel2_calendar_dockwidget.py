# -*- coding: utf-8 -*-
"""
Sentinel-2 Scene Browser Dock Widget

Provides calendar-based browsing of Sentinel-2 imagery with:
- Interactive calendar showing available dates
- Cloud coverage filtering
- Multiple visualization types (True Color, NDVI, NDVI Difference)
- Hybrid layer management (temporary browsing + optional pinning)
"""

import os
import shutil
import tempfile
import json
from datetime import datetime
from pathlib import Path

from qgis.PyQt.QtWidgets import (
    QDockWidget,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QComboBox,
    QSlider,
    QGroupBox,
    QMessageBox,
    QRadioButton,
    QButtonGroup,
    QProgressBar,
    QFrame,
    QLineEdit,
    QFileDialog
)
from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal, QDate
from qgis.PyQt.QtGui import QFont
from qgis.core import (
    QgsProject,
    QgsRasterLayer,
    QgsMessageLog,
    Qgis,
    QgsMapLayerType
)

from .custom_calendar import Sentinel2Calendar
from ..core.auth import ForestLensAuth
from ..core.api_client import ForestLensApiClient
from ..core.geometry_utils import qgis_features_to_geojson


# Visualization type mappings (matching web app)
VIZ_TYPE_MAP = {
    "True Color (Standard)": "standard",
    "True Color (Highlight Optimized)": "highlight",
    "NDVI (Vegetation Health)": "ndvi",
    "NDVI Difference (10-day Change)": "ndvi-diff"
}

VIZ_DISPLAY_NAMES = {
    "standard": "True Color",
    "highlight": "True Color (Highlight)",
    "ndvi": "NDVI",
    "ndvi-diff": "NDVI Difference"
}


class DateFetchWorker(QThread):
    """Background worker for fetching available dates."""

    progress = pyqtSignal(str)
    finished = pyqtSignal(dict)  # {date_string: cloudCoverPercent}
    error = pyqtSignal(str)

    def __init__(self, api_client, geometry, year, month):
        super().__init__()
        self.api_client = api_client
        self.geometry = geometry
        self.year = year
        self.month = month

    def run(self):
        """Fetch available dates in background thread."""
        try:
            self.progress.emit(f"Fetching available dates for {self.year}-{self.month:02d}...")

            dates_list = self.api_client.get_sentinel2_dates(
                self.geometry,
                self.year,
                self.month
            )

            # Convert list to dict for calendar
            dates_dict = {item['date']: item.get('cloudCoverPercent', 0) for item in dates_list}

            self.finished.emit(dates_dict)
        except Exception as e:
            self.error.emit(str(e))


class SceneDownloadWorker(QThread):
    """Background worker for downloading Sentinel-2 scenes."""

    progress = pyqtSignal(str)
    finished = pyqtSignal(bytes)  # GeoTIFF data
    error = pyqtSignal(str)

    def __init__(self, api_client, geometry, date, visualization_type, max_cloud_coverage):
        super().__init__()
        self.api_client = api_client
        self.geometry = geometry
        self.date = date
        self.visualization_type = visualization_type
        self.max_cloud_coverage = max_cloud_coverage

    def run(self):
        """Download scene in background thread."""
        try:
            scene_data = self.api_client.get_sentinel2_scene(
                geometry=self.geometry,
                date=self.date,
                visualization_type=self.visualization_type,
                max_cloud_coverage=self.max_cloud_coverage,
                progress_callback=self.progress.emit
            )

            self.finished.emit(scene_data)
        except Exception as e:
            self.error.emit(str(e))


class Sentinel2CalendarDockWidget(QDockWidget):
    """
    Main dock widget for Sentinel-2 Scene Browser.

    Provides calendar-based browsing with hybrid layer management:
    - Temporary browsing layer (WMS-like, updates in-place)
    - Optional pinning to create permanent layers
    """

    def __init__(self, iface, auth_manager):
        super().__init__("Sentinel-2 Scene Browser")

        self.iface = iface
        self.auth_manager = auth_manager
        self.api_client = ForestLensApiClient(auth_manager)

        # Layer tracking (hybrid approach)
        self.temporary_layer = None
        self.temporary_file = None
        self.temp_file_history = []
        self.pinned_layers = []

        # Selected state
        self.selected_date = None
        self.selected_date_info = None  # {date, cloudCoverPercent}
        self.current_geometry = None

        # Workers
        self.date_worker = None
        self.scene_worker = None

        self.init_ui()

    def init_ui(self):
        """Initialize the user interface."""
        # Create scroll area for main content
        from qgis.PyQt.QtWidgets import QScrollArea

        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)

        # Main widget and layout
        main_widget = QWidget()
        main_layout = QVBoxLayout()
        main_widget.setLayout(main_layout)

        # Set scroll area widget
        scroll_area.setWidget(main_widget)

        # Store reference to scroll area for geometry updates
        self.scroll_area = scroll_area

        self.setWidget(scroll_area)

        # =================================================================
        # GEOMETRY SOURCE SECTION
        # =================================================================
        geom_group = QGroupBox("Geometry Source")
        geom_layout = QVBoxLayout()

        geom_info = QLabel("Select geometry for imagery extent:")
        geom_info.setWordWrap(True)
        geom_info.setStyleSheet("color: gray; font-size: 9pt;")
        geom_layout.addWidget(geom_info)

        # Geometry source radio buttons
        self.geom_button_group = QButtonGroup()

        self.geom_features_radio = QRadioButton("Use Selected Features")
        self.geom_features_radio.setChecked(True)
        self.geom_button_group.addButton(self.geom_features_radio)
        geom_layout.addWidget(self.geom_features_radio)

        self.geom_extent_radio = QRadioButton("Use Current Map Extent")
        self.geom_button_group.addButton(self.geom_extent_radio)
        geom_layout.addWidget(self.geom_extent_radio)

        geom_group.setLayout(geom_layout)
        main_layout.addWidget(geom_group)

        # =================================================================
        # CLOUD COVERAGE FILTER
        # =================================================================
        cloud_group = QGroupBox("Cloud Coverage Filter")
        cloud_layout = QVBoxLayout()

        cloud_label_layout = QHBoxLayout()
        cloud_label_layout.addWidget(QLabel("Max Cloud Coverage:"))
        self.cloud_value_label = QLabel("20%")
        self.cloud_value_label.setStyleSheet("font-weight: bold;")
        cloud_label_layout.addWidget(self.cloud_value_label)
        cloud_label_layout.addStretch()
        cloud_layout.addLayout(cloud_label_layout)

        self.cloud_slider = QSlider(Qt.Horizontal)
        self.cloud_slider.setRange(0, 100)
        self.cloud_slider.setValue(20)
        self.cloud_slider.setTickPosition(QSlider.TicksBelow)
        self.cloud_slider.setTickInterval(10)
        self.cloud_slider.valueChanged.connect(self.on_cloud_slider_changed)
        cloud_layout.addWidget(self.cloud_slider)

        cloud_group.setLayout(cloud_layout)
        main_layout.addWidget(cloud_group)

        # =================================================================
        # CALENDAR SECTION
        # =================================================================
        calendar_group = QGroupBox("Available Dates")
        calendar_layout = QVBoxLayout()

        # Refresh button
        refresh_button_layout = QHBoxLayout()
        self.refresh_button = QPushButton("Refresh Calendar")
        self.refresh_button.clicked.connect(self.refresh_calendar)
        refresh_button_layout.addWidget(self.refresh_button)
        refresh_button_layout.addStretch()
        calendar_layout.addLayout(refresh_button_layout)

        # Calendar widget
        self.calendar = Sentinel2Calendar()
        self.calendar.clicked.connect(self.on_date_selected)
        self.calendar.currentPageChanged.connect(self.on_month_changed)
        calendar_layout.addWidget(self.calendar)

        # Calendar legend
        legend_layout = QHBoxLayout()
        legend_layout.addWidget(QLabel("🔵 Available"))
        legend_layout.addWidget(QLabel("⚪ Cloudy"))
        legend_layout.addStretch()
        calendar_layout.addLayout(legend_layout)

        calendar_group.setLayout(calendar_layout)
        main_layout.addWidget(calendar_group)

        # =================================================================
        # SELECTED DATE INFO
        # =================================================================
        info_group = QGroupBox("Selected Date")
        info_layout = QVBoxLayout()

        self.date_info_label = QLabel("No date selected")
        self.date_info_label.setStyleSheet("font-size: 10pt; padding: 5px;")
        info_layout.addWidget(self.date_info_label)

        info_group.setLayout(info_layout)
        main_layout.addWidget(info_group)

        # =================================================================
        # VISUALIZATION TYPE SELECTOR
        # =================================================================
        viz_group = QGroupBox("Visualization Type")
        viz_layout = QVBoxLayout()

        self.viz_combo = QComboBox()
        self.viz_combo.addItems([
            "True Color (Standard)",
            "True Color (Highlight Optimized)",
            "NDVI (Vegetation Health)",
            "NDVI Difference (10-day Change)"
        ])
        viz_layout.addWidget(self.viz_combo)

        viz_group.setLayout(viz_layout)
        main_layout.addWidget(viz_group)

        # =================================================================
        # OUTPUT DIRECTORY SELECTOR
        # =================================================================
        output_group = QGroupBox("Output Directory")
        output_layout = QVBoxLayout()

        dir_selector_layout = QHBoxLayout()

        self.output_dir_input = QLineEdit()
        self.output_dir_input.setPlaceholderText("Default: Project directory or temporary")
        # Default to project home path if available, else temp
        default_dir = QgsProject.instance().homePath() or tempfile.gettempdir()
        self.output_dir_input.setText(default_dir)
        self.output_dir_input.setReadOnly(True)
        dir_selector_layout.addWidget(self.output_dir_input)

        self.browse_dir_button = QPushButton("Browse...")
        self.browse_dir_button.clicked.connect(self.browse_output_directory)
        dir_selector_layout.addWidget(self.browse_dir_button)

        output_layout.addLayout(dir_selector_layout)
        output_group.setLayout(output_layout)
        main_layout.addWidget(output_group)

        # =================================================================
        # ACTION BUTTONS
        # =================================================================
        action_group = QGroupBox("Actions")
        action_layout = QVBoxLayout()

        # Load Preview button
        self.load_button = QPushButton("Load Preview")
        self.load_button.clicked.connect(self.load_scene_preview)
        self.load_button.setEnabled(False)
        self.load_button.setStyleSheet("QPushButton { padding: 8px; font-weight: bold; }")
        action_layout.addWidget(self.load_button)

        # Pin Layer button
        self.save_button = QPushButton("Save Result")
        self.save_button.clicked.connect(self.save_current_scene)
        self.save_button.setEnabled(False)
        action_layout.addWidget(self.save_button)

        action_group.setLayout(action_layout)
        main_layout.addWidget(action_group)

        # =================================================================
        # LAYER OPACITY CONTROL
        # =================================================================
        opacity_group = QGroupBox("Layer Opacity")
        opacity_layout = QVBoxLayout()

        opacity_label_layout = QHBoxLayout()
        opacity_label_layout.addWidget(QLabel("Opacity:"))
        self.opacity_value_label = QLabel("100%")
        self.opacity_value_label.setStyleSheet("font-weight: bold;")
        opacity_label_layout.addWidget(self.opacity_value_label)
        opacity_label_layout.addStretch()
        opacity_layout.addLayout(opacity_label_layout)

        self.opacity_slider = QSlider(Qt.Horizontal)
        self.opacity_slider.setRange(0, 100)
        self.opacity_slider.setValue(100)
        self.opacity_slider.setTickPosition(QSlider.TicksBelow)
        self.opacity_slider.setTickInterval(10)
        self.opacity_slider.valueChanged.connect(self.update_layer_opacity)
        self.opacity_slider.setEnabled(False)
        opacity_layout.addWidget(self.opacity_slider)

        opacity_group.setLayout(opacity_layout)
        main_layout.addWidget(opacity_group)

        # =================================================================
        # PROGRESS/STATUS
        # =================================================================
        self.progress_label = QLabel("")
        self.progress_label.setStyleSheet("color: gray; font-size: 9pt; font-style: italic;")
        self.progress_label.setWordWrap(True)
        main_layout.addWidget(self.progress_label)

        # Add stretch to push everything to top
        main_layout.addStretch()

    def showEvent(self, event):
        """Handle show event - force scroll area geometry update."""
        super().showEvent(event)
        if hasattr(self, 'scroll_area'):
            self.scroll_area.updateGeometry()
            # Force scroll bars to recalculate
            self.scroll_area.widget().updateGeometry()

    def on_cloud_slider_changed(self, value):
        """Update cloud coverage filter."""
        self.cloud_value_label.setText(f"{value}%")
        self.calendar.set_cloud_threshold(value)

    def refresh_calendar(self):
        """Refresh calendar for current month."""
        year = self.calendar.yearShown()
        month = self.calendar.monthShown()
        QgsMessageLog.logMessage(
            f"[Calendar] Refreshing calendar - Year: {year}, Month: {month} (monthShown returns 1-based: 1=January)",
            'ForestLens',
            Qgis.Info
        )
        self.fetch_available_dates(year, month)

    def on_month_changed(self, year, month):
        """Handle month/year change in calendar."""
        QgsMessageLog.logMessage(
            f"[Calendar] Month changed - Year: {year}, Month: {month} (currentPageChanged signal passes 1-based month)",
            'ForestLens',
            Qgis.Info
        )
        self.fetch_available_dates(year, month)

    def fetch_available_dates(self, year, month):
        """Fetch available dates for the given month."""
        QgsMessageLog.logMessage(
            f"[Calendar] fetch_available_dates called - Year: {year}, Month: {month}",
            'ForestLens',
            Qgis.Info
        )

        # Get current geometry
        try:
            geometry = self.get_current_geometry()
            if not geometry:
                self.progress_label.setText("⚠ No geometry selected. Please select features or enable map extent mode.")
                return
        except Exception as e:
            self.progress_label.setText(f"⚠ Error getting geometry: {str(e)}")
            return

        # Check if already fetching
        if self.date_worker and self.date_worker.isRunning():
            return

        # Create worker
        self.date_worker = DateFetchWorker(self.api_client, geometry, year, month)
        self.date_worker.progress.connect(self.progress_label.setText)
        self.date_worker.finished.connect(self.on_dates_fetched)
        self.date_worker.error.connect(self.on_dates_fetch_error)

        # Disable refresh button
        self.refresh_button.setEnabled(False)

        # Start worker
        self.date_worker.start()

    def on_dates_fetched(self, dates_dict):
        """Handle fetched dates."""
        self.calendar.set_available_dates(dates_dict)
        self.progress_label.setText(f"✓ Found {len(dates_dict)} available dates")
        self.refresh_button.setEnabled(True)

    def on_dates_fetch_error(self, error_msg):
        """Handle error fetching dates."""
        self.progress_label.setText(f"✗ Error: {error_msg}")
        self.refresh_button.setEnabled(True)
        QMessageBox.critical(self, "Error", f"Failed to fetch available dates:\n{error_msg}")

    def on_date_selected(self, qdate: QDate):
        """Handle date selection from calendar."""
        # Convert QDate to string
        date_str = qdate.toString("yyyy-MM-dd")

        # Check if date is available
        if date_str not in self.calendar.available_dates:
            QMessageBox.information(self, "No Data", f"No Sentinel-2 data available for {date_str}")
            return

        # Store selected date
        self.selected_date = date_str
        cloud_cover = self.calendar.available_dates[date_str]
        self.selected_date_info = {
            'date': date_str,
            'cloudCoverPercent': cloud_cover
        }

        # Update info label
        self.date_info_label.setText(
            f"Date: {date_str}\n"
            f"Cloud Coverage: {cloud_cover:.1f}%"
        )

        # Enable load button
        self.load_button.setEnabled(True)

    def get_current_geometry(self):
        """Get current geometry based on selected source."""
        if self.geom_features_radio.isChecked():
            # Use selected features
            layer = self.iface.activeLayer()
            if not layer or layer.type() != QgsMapLayerType.VectorLayer:
                raise Exception("No active vector layer")

            selected_features = layer.selectedFeatures()
            if not selected_features:
                raise Exception("No features selected")

            return qgis_features_to_geojson(selected_features, layer.crs())

        else:
            # Use map extent
            from qgis.core import QgsGeometry, QgsRectangle, QgsCoordinateTransform, QgsCoordinateReferenceSystem
            from ..core.geometry_utils import qgis_geometry_to_geojson

            extent = self.iface.mapCanvas().extent()
            source_crs = self.iface.mapCanvas().mapSettings().destinationCrs()

            # Create polygon from extent
            extent_geometry = QgsGeometry.fromRect(extent)

            # Check extent size in WGS84 (degrees)
            # Transform to WGS84 to check bbox size
            target_crs = QgsCoordinateReferenceSystem("EPSG:4326")
            if source_crs != target_crs:
                transform = QgsCoordinateTransform(source_crs, target_crs, QgsProject.instance())
                check_geom = QgsGeometry(extent_geometry)
                check_geom.transform(transform)
                wgs84_extent = check_geom.boundingBox()
            else:
                wgs84_extent = extent

            # Check if extent is too large (max ~5 degrees in any direction ≈ 550km at equator)
            width_degrees = wgs84_extent.width()
            height_degrees = wgs84_extent.height()
            max_extent_degrees = 5.0

            if width_degrees > max_extent_degrees or height_degrees > max_extent_degrees:
                raise Exception(
                    f"Map extent too large ({width_degrees:.2f}° x {height_degrees:.2f}°). "
                    f"Maximum is {max_extent_degrees}° (~550 km). "
                    f"Please zoom in or select specific features instead."
                )

            # Convert to GeoJSON (this will reproject to WGS84)
            geojson = qgis_geometry_to_geojson(extent_geometry, source_crs)

            if not geojson:
                raise Exception("Failed to convert map extent to GeoJSON")

            return geojson

    def get_selected_visualization_type(self) -> str:
        """Get current visualization type (standard|highlight|ndvi|ndvi-diff)."""
        display_name = self.viz_combo.currentText()
        return VIZ_TYPE_MAP[display_name]

    def configure_layer_rendering(self, layer: QgsRasterLayer, viz_type: str):
        """
        Configure layer rendering based on visualization type.

        For True Color (standard/highlight): 4 bands (RGB + alpha)
        For NDVI: 3 bands (RGB)
        For NDVI Difference: 4 bands (RGB + alpha)

        When band 4 is alpha/dataMask and equals 0, pixels should be transparent.
        """
        from qgis.core import QgsRasterRenderer, QgsMultiBandColorRenderer, QgsContrastEnhancement

        band_count = layer.bandCount()

        QgsMessageLog.logMessage(
            f"[Rendering] Configuring {viz_type} with {band_count} bands",
            'ForestLens',
            Qgis.Info
        )

        # True Color visualizations (standard/highlight) have 4 bands: RGB + alpha
        if viz_type in ['standard', 'highlight']:
            if band_count == 4:
                # Create multiband renderer with bands 1,2,3 as RGB
                renderer = QgsMultiBandColorRenderer(
                    layer.dataProvider(),
                    1,  # Red band
                    2,  # Green band
                    3   # Blue band
                )

                # Set band 4 as alpha channel (nodata mask)
                # When band 4 = 0, pixel should be transparent
                renderer.setAlphaBand(4)

                # Apply renderer
                layer.setRenderer(renderer)

                QgsMessageLog.logMessage(
                    f"[Rendering] Set bands 1,2,3 as RGB and band 4 as alpha for {viz_type}",
                    'ForestLens',
                    Qgis.Info
                )

        # NDVI has 3 bands (RGB, no alpha needed)
        elif viz_type == 'ndvi':
            if band_count == 3:
                renderer = QgsMultiBandColorRenderer(
                    layer.dataProvider(),
                    1,  # Red band
                    2,  # Green band
                    3   # Blue band
                )
                layer.setRenderer(renderer)

                QgsMessageLog.logMessage(
                    f"[Rendering] Set bands 1,2,3 as RGB for NDVI",
                    'ForestLens',
                    Qgis.Info
                )

        # NDVI Difference has 4 bands: RGB + alpha
        elif viz_type == 'ndvi-diff':
            if band_count == 4:
                renderer = QgsMultiBandColorRenderer(
                    layer.dataProvider(),
                    1,  # Red band
                    2,  # Green band
                    3   # Blue band
                )

                # Set band 4 as alpha channel
                renderer.setAlphaBand(4)
                layer.setRenderer(renderer)

                QgsMessageLog.logMessage(
                    f"[Rendering] Set bands 1,2,3 as RGB and band 4 as alpha for NDVI Difference",
                    'ForestLens',
                    Qgis.Info
                )

        # Trigger layer repaint
        layer.triggerRepaint()

    def load_scene_preview(self):
        """Load scene as temporary browsing layer."""
        if not self.selected_date:
            QMessageBox.warning(self, "No Date", "Please select a date first")
            return

        # Check if already downloading
        if self.scene_worker and self.scene_worker.isRunning():
            return

        try:
            # Get geometry
            geometry = self.get_current_geometry()
            if not geometry:
                raise Exception("No geometry selected")

            # Get visualization type
            viz_type = self.get_selected_visualization_type()

            # Show loading state
            self.load_button.setEnabled(False)
            self.progress_label.setText(f"Loading {self.selected_date}...")

            # Create worker
            self.scene_worker = SceneDownloadWorker(
                self.api_client,
                geometry,
                self.selected_date,
                viz_type,
                self.cloud_slider.value()
            )
            self.scene_worker.progress.connect(self.progress_label.setText)
            self.scene_worker.finished.connect(self.on_scene_downloaded)
            self.scene_worker.error.connect(self.on_scene_download_error)

            # Start download
            self.scene_worker.start()

        except Exception as e:
            self.progress_label.setText(f"✗ Error: {str(e)}")
            self.load_button.setEnabled(True)
            QMessageBox.critical(self, "Error", f"Failed to load scene:\n{str(e)}")

    def on_scene_downloaded(self, scene_data: bytes):
        """Handle downloaded scene data."""
        try:
            viz_type = self.get_selected_visualization_type()

            # Save to temporary file
            temp_file = os.path.join(
                tempfile.gettempdir(),
                f"sentinel2_preview_{self.selected_date}_{viz_type}.tif"
            )
            with open(temp_file, 'wb') as f:
                f.write(scene_data)

            # Remove old temporary layer
            if self.temporary_layer:
                QgsProject.instance().removeMapLayer(self.temporary_layer)

            # Create new temporary layer
            self.temporary_layer = QgsRasterLayer(temp_file, "🔍 Sentinel-2 Browser")

            if not self.temporary_layer.isValid():
                raise Exception("Failed to load GeoTIFF")

            # Configure renderer based on band count and visualization type
            self.configure_layer_rendering(self.temporary_layer, viz_type)

            # Set opacity
            opacity = self.opacity_slider.value() / 100.0
            self.temporary_layer.renderer().setOpacity(opacity)

            # Add to project (below active layer)
            self.insert_layer_below_active(self.temporary_layer)

            # Track for cleanup
            self.temporary_file = temp_file
            self.temp_file_history.append(temp_file)
            self.cleanup_old_temp_files()

            # Update UI
            self.save_button.setEnabled(True)
            self.opacity_slider.setEnabled(True)
            self.progress_label.setText(f"✓ Loaded {self.selected_date}")

        except Exception as e:
            self.progress_label.setText(f"✗ Error loading scene")
            QMessageBox.critical(self, "Error", f"Failed to load scene:\n{str(e)}")
        finally:
            self.load_button.setEnabled(True)

    def on_scene_download_error(self, error_msg):
        """Handle scene download error."""
        self.progress_label.setText(f"✗ Error: {error_msg}")
        self.load_button.setEnabled(True)
        QMessageBox.critical(self, "Error", f"Failed to download scene:\n{error_msg}")

    def save_current_scene(self):
        """Save temporary layer as permanent result."""
        if not self.temporary_layer or not self.selected_date:
            return

        # Get visualization display name
        viz_type = self.get_selected_visualization_type()
        viz_display = VIZ_DISPLAY_NAMES[viz_type]

        # Create permanent layer name
        permanent_name = f"Sentinel-2 {self.selected_date} {viz_display}"

        # Clone layer
        permanent_layer = self.temporary_layer.clone()
        permanent_layer.setName(permanent_name)

        # Copy to permanent location (use selected output directory)
        output_dir = self.output_dir_input.text() or QgsProject.instance().homePath() or tempfile.gettempdir()
        permanent_file = os.path.join(
            output_dir,
            f"sentinel2_{self.selected_date}_{viz_type}.tif"
        )

        try:
            shutil.copy(self.temporary_file, permanent_file)

            # Update layer source
            permanent_layer.setDataSource(permanent_file, permanent_name, "gdal")

            # Re-configure rendering for permanent layer (in case renderer was lost during clone/setDataSource)
            self.configure_layer_rendering(permanent_layer, viz_type)

            # Add to project
            QgsProject.instance().addMapLayer(permanent_layer)

            # Track
            self.pinned_layers.append({
                'layer': permanent_layer,
                'date': self.selected_date,
                'viz': viz_display,
                'file': permanent_file
            })

            QMessageBox.information(
                self,
                "Layer Pinned",
                f"Permanent layer created:\n{permanent_name}\n\n"
                f"File saved to:\n{permanent_file}\n\n"
                f"The browsing layer remains active for continued exploration."
            )

        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to pin layer:\n{str(e)}")

    def browse_output_directory(self):
        """Open directory browser for output directory selection."""
        current_dir = self.output_dir_input.text() or tempfile.gettempdir()

        directory = QFileDialog.getExistingDirectory(
            self,
            "Select Output Directory",
            current_dir,
            QFileDialog.ShowDirsOnly | QFileDialog.DontResolveSymlinks
        )

        if directory:
            self.output_dir_input.setText(directory)
            QgsMessageLog.logMessage(
                f"Output directory set to: {directory}",
                'ForestLens',
                Qgis.Info
            )

    def update_layer_opacity(self, value):
        """Update opacity of temporary layer."""
        self.opacity_value_label.setText(f"{value}%")

        if self.temporary_layer:
            opacity = value / 100.0
            self.temporary_layer.renderer().setOpacity(opacity)
            self.temporary_layer.triggerRepaint()

    def cleanup_old_temp_files(self):
        """Keep only last 3 temporary files."""
        MAX_TEMP_FILES = 3
        if len(self.temp_file_history) > MAX_TEMP_FILES:
            old_files = self.temp_file_history[:-MAX_TEMP_FILES]
            for file_path in old_files:
                if os.path.exists(file_path):
                    try:
                        os.remove(file_path)
                    except:
                        pass
            self.temp_file_history = self.temp_file_history[-MAX_TEMP_FILES:]

    def insert_layer_below_active(self, layer):
        """Insert layer below currently active layer."""
        # Add without showing in legend first
        QgsProject.instance().addMapLayer(layer, False)

        # Get layer tree
        root = QgsProject.instance().layerTreeRoot()
        active_layer = self.iface.activeLayer()

        if active_layer:
            active_node = root.findLayer(active_layer.id())
            if active_node:
                parent = active_node.parent()
                if parent:
                    index = parent.children().index(active_node)
                    parent.insertLayer(index + 1, layer)
                    return

        # Fallback: add to root
        root.addLayer(layer)
