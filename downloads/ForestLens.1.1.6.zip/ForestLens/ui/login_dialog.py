# -*- coding: utf-8 -*-
"""
ForestLens QGIS Plugin - Login Dialog

Dialog for user authentication with ForestLens.
"""

from qgis.PyQt.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QMessageBox,
    QCheckBox,
    QFrame
)
from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.PyQt.QtGui import QFont


class LoginDialog(QDialog):
    """
    Login dialog for ForestLens authentication.

    Emits login_successful signal when authentication succeeds.
    """

    login_successful = pyqtSignal()

    def __init__(self, auth_manager, parent=None):
        """
        Initialize login dialog.

        Args:
            auth_manager: ForestLensAuth instance
            parent: Parent widget
        """
        super().__init__(parent)
        self.auth_manager = auth_manager
        self.setup_ui()

    def setup_ui(self):
        """Setup the user interface."""
        self.setWindowTitle("ForestLens Login")
        self.setMinimumWidth(400)
        self.setModal(True)

        layout = QVBoxLayout()
        layout.setSpacing(15)

        # Header
        header_label = QLabel("ForestLens QGIS Plugin")
        header_font = QFont()
        header_font.setPointSize(14)
        header_font.setBold(True)
        header_label.setFont(header_font)
        header_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(header_label)

        subtitle_label = QLabel("Login with your ForestLens account")
        subtitle_label.setAlignment(Qt.AlignCenter)
        subtitle_label.setStyleSheet("color: gray;")
        layout.addWidget(subtitle_label)

        # Separator
        separator = QFrame()
        separator.setFrameShape(QFrame.HLine)
        separator.setFrameShadow(QFrame.Sunken)
        layout.addWidget(separator)

        # Email field
        email_label = QLabel("Email:")
        layout.addWidget(email_label)

        self.email_input = QLineEdit()
        self.email_input.setPlaceholderText("your.email@example.com")
        self.email_input.returnPressed.connect(self.on_login)
        layout.addWidget(self.email_input)

        # Password field
        password_label = QLabel("Password:")
        layout.addWidget(password_label)

        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.Password)
        self.password_input.setPlaceholderText("Your password")
        self.password_input.returnPressed.connect(self.on_login)
        layout.addWidget(self.password_input)

        # Remember me (informational only)
        remember_label = QLabel("✓ Session will be saved securely")
        remember_label.setStyleSheet("color: green; font-size: 10pt;")
        layout.addWidget(remember_label)

        # Buttons
        button_layout = QHBoxLayout()

        self.login_button = QPushButton("Login")
        self.login_button.setDefault(True)
        self.login_button.clicked.connect(self.on_login)
        button_layout.addWidget(self.login_button)

        self.cancel_button = QPushButton("Cancel")
        self.cancel_button.clicked.connect(self.reject)
        button_layout.addWidget(self.cancel_button)

        layout.addLayout(button_layout)

        # Help text
        help_label = QLabel(
            'Don\'t have an account? Visit <a href="https://forestlens.com">forestlens.com</a>'
        )
        help_label.setOpenExternalLinks(True)
        help_label.setAlignment(Qt.AlignCenter)
        help_label.setStyleSheet("font-size: 9pt; color: gray;")
        layout.addWidget(help_label)

        self.setLayout(layout)

        # Focus on email field
        self.email_input.setFocus()

    def on_login(self):
        """Handle login button click."""
        email = self.email_input.text().strip()
        password = self.password_input.text()

        if not email or not password:
            QMessageBox.warning(
                self,
                "Input Required",
                "Please enter both email and password."
            )
            return

        # Disable UI during login
        self.set_ui_enabled(False)
        self.login_button.setText("Logging in...")

        # Attempt login
        success, message = self.auth_manager.login(email, password)

        # Re-enable UI
        self.set_ui_enabled(True)
        self.login_button.setText("Login")

        if success:
            QMessageBox.information(
                self,
                "Login Successful",
                message
            )
            self.login_successful.emit()
            self.accept()
        else:
            QMessageBox.warning(
                self,
                "Login Failed",
                message
            )
            self.password_input.clear()
            self.password_input.setFocus()

    def set_ui_enabled(self, enabled: bool):
        """Enable or disable UI elements."""
        self.email_input.setEnabled(enabled)
        self.password_input.setEnabled(enabled)
        self.login_button.setEnabled(enabled)
        self.cancel_button.setEnabled(enabled)
