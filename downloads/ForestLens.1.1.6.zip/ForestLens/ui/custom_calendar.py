# -*- coding: utf-8 -*-
"""
Custom Calendar Widget for Sentinel-2 Scene Browser

Displays available Sentinel-2 dates with visual indicators:
- Blue cells: Available dates (cloud coverage below threshold)
- Gray cells: Cloudy dates (cloud coverage above threshold)
- Disabled cells: No data available
"""

from qgis.PyQt.QtWidgets import QCalendarWidget, QToolTip
from qgis.PyQt.QtCore import Qt, QDate, QPoint
from qgis.PyQt.QtGui import QColor, QPainter, QTextCharFormat, QPen
from datetime import date


class Sentinel2Calendar(QCalendarWidget):
    """
    Custom calendar widget that highlights available Sentinel-2 dates.

    Features:
    - Blue highlighting for available dates (low cloud coverage)
    - Gray highlighting for cloudy dates (high cloud coverage)
    - Tooltips showing cloud coverage percentage
    - Month/year navigation
    """

    def __init__(self, parent=None):
        super().__init__(parent)

        # Data structures
        self.available_dates = {}  # {date_string: cloudCoverPercent}
        self.cloud_threshold = 20  # Default threshold for "available" vs "cloudy"

        # UI setup
        self.setGridVisible(True)
        self.setVerticalHeaderFormat(QCalendarWidget.NoVerticalHeader)
        self.setNavigationBarVisible(True)
        self.setFirstDayOfWeek(Qt.Monday)

        # Enable tooltips
        self.setMouseTracking(True)

        # Apply custom formatting
        self._setup_formatting()

    def _setup_formatting(self):
        """Setup calendar formatting"""
        # Header format (weekday names)
        header_format = QTextCharFormat()
        header_format.setFontWeight(600)
        self.setHeaderTextFormat(header_format)

        # Weekday format
        weekday_format = QTextCharFormat()
        self.setWeekdayTextFormat(Qt.Monday, weekday_format)
        self.setWeekdayTextFormat(Qt.Tuesday, weekday_format)
        self.setWeekdayTextFormat(Qt.Wednesday, weekday_format)
        self.setWeekdayTextFormat(Qt.Thursday, weekday_format)
        self.setWeekdayTextFormat(Qt.Friday, weekday_format)
        self.setWeekdayTextFormat(Qt.Saturday, weekday_format)
        self.setWeekdayTextFormat(Qt.Sunday, weekday_format)

    def set_available_dates(self, dates_data: dict):
        """
        Set available dates with cloud coverage data.

        Args:
            dates_data: Dictionary mapping date strings to cloud coverage percentages
                       Example: {"2024-06-15": 8.5, "2024-06-20": 15.2}
        """
        self.available_dates = dates_data
        self.updateCells()

    def set_cloud_threshold(self, threshold: int):
        """
        Set cloud coverage threshold for determining "available" vs "cloudy".

        Args:
            threshold: Cloud coverage percentage (0-100)
        """
        self.cloud_threshold = threshold
        self.updateCells()

    def clear_dates(self):
        """Clear all available dates"""
        self.available_dates = {}
        self.updateCells()

    def paintCell(self, painter: QPainter, rect, qdate: QDate):
        """
        Custom cell painting for availability status.

        Args:
            painter: QPainter instance
            rect: Cell rectangle
            qdate: QDate for the cell
        """
        # Convert QDate to string format (YYYY-MM-DD)
        date_str = qdate.toString("yyyy-MM-dd")

        # Check if this date has data
        if date_str in self.available_dates:
            cloud_cover = self.available_dates[date_str]

            # Determine color based on cloud coverage
            if cloud_cover <= self.cloud_threshold:
                # Blue for available dates (low cloud)
                bg_color = QColor(100, 150, 255, 150)  # Light blue with transparency
                text_color = QColor(0, 0, 0)
            else:
                # Gray for cloudy dates
                bg_color = QColor(180, 180, 180, 150)  # Light gray with transparency
                text_color = QColor(60, 60, 60)

            # Fill background
            painter.fillRect(rect, bg_color)

            # Draw date number
            painter.setPen(QPen(text_color))
            painter.drawText(rect, Qt.AlignCenter, str(qdate.day()))

        else:
            # No data - use default painting
            super().paintCell(painter, rect, qdate)

    def mouseMoveEvent(self, event):
        """Show tooltip with cloud coverage on mouse hover"""
        # Get the date at cursor position
        qdate = self.dateAt(event.pos())

        if qdate.isValid():
            date_str = qdate.toString("yyyy-MM-dd")

            if date_str in self.available_dates:
                cloud_cover = self.available_dates[date_str]
                tooltip_text = f"{date_str}\nCloud Coverage: {cloud_cover:.1f}%"

                # Show tooltip
                QToolTip.showText(event.globalPos(), tooltip_text, self)
            else:
                QToolTip.hideText()
        else:
            QToolTip.hideText()

        super().mouseMoveEvent(event)

    def dateAt(self, pos: QPoint):
        """
        Get the QDate at the given position.

        Args:
            pos: QPoint position

        Returns:
            QDate at the position, or invalid QDate if not over a date cell
        """
        # Calculate which date is at this position
        # This is an approximation since QCalendarWidget doesn't expose this directly

        # Get viewport
        viewport = self.findChild(type(self).__bases__[0])
        if not viewport:
            return QDate()

        # Simple grid calculation
        # Note: This is a rough estimate and may need adjustment
        cell_width = self.width() / 7
        cell_height = (self.height() - 50) / 6  # Subtract header height

        col = int(pos.x() / cell_width)
        row = int((pos.y() - 50) / cell_height)  # Subtract header height

        if row < 0 or col < 0 or col > 6:
            return QDate()

        # Get first day of month
        first_day = QDate(self.yearShown(), self.monthShown(), 1)
        first_weekday = first_day.dayOfWeek()  # 1=Monday, 7=Sunday

        # Calculate offset
        day_offset = (row * 7 + col) - (first_weekday - 1)

        if day_offset < 0:
            return QDate()

        result_date = first_day.addDays(day_offset)

        # Check if still in current month
        if result_date.month() != self.monthShown():
            return QDate()

        return result_date
