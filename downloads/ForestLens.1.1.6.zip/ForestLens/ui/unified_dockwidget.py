# -*- coding: utf-8 -*-
"""
ForestLens QGIS Plugin - Unified Dock Widget

Single dock widget with tabs for Analysis and Sentinel-2 Browser.
"""

from qgis.PyQt.QtWidgets import (
    QDockWidget,
    QWidget,
    QVBoxLayout,
    QTabWidget
)
from qgis.PyQt.QtCore import Qt

from .main_dockwidget import ForestLensDockWidget
from .sentinel2_calendar_dockwidget import Sentinel2CalendarDockWidget


class UnifiedForestLensDockWidget(QDockWidget):
    """
    Unified dock widget with tabs for Analysis and Sentinel-2 Browser.

    Provides a single plugin interface with two modes:
    - Analysis: Forest change detection and analysis
    - Sentinel-2 Browser: Calendar-based imagery browsing
    """

    def __init__(self, iface, auth_manager, parent=None):
        """
        Initialize unified dock widget.

        Args:
            iface: QGIS interface
            auth_manager: ForestLensAuth instance
            parent: Parent widget
        """
        super().__init__("ForestLens", parent)

        self.iface = iface
        self.auth_manager = auth_manager

        # Create main widget with tabs
        main_widget = QWidget()
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(0, 0, 0, 0)  # Remove margins for better tab display
        main_widget.setLayout(main_layout)

        # Create tab widget
        self.tab_widget = QTabWidget()
        main_layout.addWidget(self.tab_widget)

        # Create the actual dock widgets (they'll manage their own content)
        self.analysis_dock = ForestLensDockWidget(self.iface, self.auth_manager)
        self.calendar_dock = Sentinel2CalendarDockWidget(self.iface, self.auth_manager)

        # Extract their content widgets and add to tabs
        # Both dock widgets set their content via setWidget(), so we can extract it
        analysis_content = self.analysis_dock.widget()
        calendar_content = self.calendar_dock.widget()

        self.tab_widget.addTab(analysis_content, "Analysis")
        self.tab_widget.addTab(calendar_content, "Sentinel-2 Browser")

        # Set main widget
        self.setWidget(main_widget)

    def switch_to_analysis(self):
        """Switch to Analysis tab."""
        self.tab_widget.setCurrentIndex(0)

    def switch_to_calendar(self):
        """Switch to Sentinel-2 Browser tab."""
        self.tab_widget.setCurrentIndex(1)
