# -*- coding: utf-8 -*-
"""
ForestLens QGIS Plugin - Direct CDSE API Client

Handles communication with Copernicus Data Space Ecosystem (CDSE) API
including OAuth2 authentication and token refresh.

Similar to CDSEApiClient in web app but for Python/QGIS.
"""

import time
import requests
from typing import Dict, Optional, Tuple
from qgis.core import QgsMessageLog, Qgis


class CDSEApiClient:
    """
    Client for Copernicus Data Space Ecosystem Sentinel Hub API.

    Handles OAuth2 authentication with automatic token refresh.
    """

    def __init__(self, client_id: str, client_secret: str):
        """
        Initialize CDSE API client.

        Args:
            client_id: OAuth2 client ID
            client_secret: OAuth2 client secret
        """
        self.client_id = client_id
        self.client_secret = client_secret

        # OAuth2 token state
        self._access_token: Optional[str] = None
        self._token_expires_at: Optional[int] = None

        # API endpoints
        self.token_url = "https://identity.dataspace.copernicus.eu/auth/realms/CDSE/protocol/openid-connect/token"
        self.process_url = "https://sh.dataspace.copernicus.eu/api/v1/process"

    def _log(self, message: str, level: Qgis.MessageLevel = Qgis.Info):
        """Log message to QGIS log panel."""
        QgsMessageLog.logMessage(message, 'ForestLens-CDSE', level)

    def _get_access_token(self) -> str:
        """
        Get valid access token, refreshing if needed.

        Returns:
            str: Valid access token

        Raises:
            RuntimeError: If token acquisition fails
        """
        # Check if token is valid
        now = int(time.time())
        if self._access_token and self._token_expires_at and now < self._token_expires_at - 60:
            return self._access_token

        # Request new token
        self._log("Requesting new CDSE access token")

        try:
            response = requests.post(
                self.token_url,
                data={
                    'grant_type': 'client_credentials',
                    'client_id': self.client_id,
                    'client_secret': self.client_secret
                },
                timeout=30
            )

            if response.status_code != 200:
                raise RuntimeError(f"Failed to get CDSE token: HTTP {response.status_code}")

            data = response.json()
            self._access_token = data['access_token']
            expires_in = data.get('expires_in', 3600)
            self._token_expires_at = now + expires_in

            self._log(f"CDSE token acquired, expires in {expires_in}s")
            return self._access_token

        except Exception as e:
            self._log(f"Failed to get CDSE access token: {str(e)}", Qgis.Critical)
            raise RuntimeError(f"CDSE authentication failed: {str(e)}")

    def process_evalscript(
        self,
        evalscript: str,
        geometry: Dict,
        time_range: Tuple[str, str],
        resolution: int = 10,
        crs: str = "EPSG:3857",
        output_format: str = "image/tiff",
        max_retries: int = 3
    ) -> bytes:
        """
        Execute evalscript against CDSE Process API.

        Args:
            evalscript: JavaScript evalscript code
            geometry: GeoJSON geometry dict
            time_range: Tuple of (from_date, to_date) in ISO format
            resolution: Spatial resolution in meters (default: 10m)
            crs: Coordinate reference system (default: EPSG:3857)
            output_format: Output format (default: image/tiff)
            max_retries: Number of retries on failure

        Returns:
            bytes: GeoTIFF image data

        Raises:
            RuntimeError: If request fails after retries
        """
        # Get access token
        token = self._get_access_token()

        # Build Process API request
        request_body = {
            "input": {
                "bounds": {
                    "geometry": geometry,
                    "properties": {"crs": crs}
                },
                "data": [{
                    "type": "sentinel-2-l2a",
                    "dataFilter": {
                        "timeRange": {
                            "from": f"{time_range[0]}T00:00:00Z",
                            "to": f"{time_range[1]}T23:59:59Z"
                        }
                    }
                }]
            },
            "output": {
                "width": 512,
                "height": 512,
                "responses": [{
                    "identifier": "default",
                    "format": {"type": output_format}
                }]
            },
            "evalscript": evalscript
        }

        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "Accept": output_format
        }

        # Execute request with retries
        for attempt in range(max_retries):
            try:
                self._log(f"Calling CDSE Process API (attempt {attempt + 1}/{max_retries})")

                response = requests.post(
                    self.process_url,
                    json=request_body,
                    headers=headers,
                    timeout=300  # 5 minutes for large requests
                )

                if response.status_code == 200:
                    self._log(f"CDSE request successful ({len(response.content)} bytes)")
                    return response.content

                elif response.status_code == 401:
                    # Token expired mid-request - refresh and retry
                    self._log("CDSE token expired, refreshing...", Qgis.Warning)
                    self._access_token = None
                    token = self._get_access_token()
                    headers["Authorization"] = f"Bearer {token}"
                    continue

                elif response.status_code == 429:
                    # Rate limited
                    if attempt < max_retries - 1:
                        wait_time = (2 ** attempt) * 2
                        self._log(f"CDSE rate limited, waiting {wait_time}s", Qgis.Warning)
                        time.sleep(wait_time)
                        continue
                    else:
                        raise RuntimeError("CDSE rate limit exceeded")

                else:
                    error_msg = f"CDSE request failed: HTTP {response.status_code}"
                    try:
                        error_data = response.json()
                        error_msg += f" - {error_data}"
                    except:
                        error_msg += f" - {response.text[:200]}"

                    self._log(error_msg, Qgis.Critical)
                    raise RuntimeError(error_msg)

            except requests.exceptions.Timeout:
                if attempt < max_retries - 1:
                    self._log(f"CDSE request timeout, retrying...", Qgis.Warning)
                    continue
                else:
                    raise RuntimeError("CDSE request timeout")

            except Exception as e:
                if attempt < max_retries - 1:
                    self._log(f"CDSE request error: {str(e)}, retrying...", Qgis.Warning)
                    time.sleep(2 ** attempt)
                    continue
                else:
                    raise RuntimeError(f"CDSE request failed: {str(e)}")

        raise RuntimeError(f"CDSE request failed after {max_retries} attempts")
