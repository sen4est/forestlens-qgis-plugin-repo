# -*- coding: utf-8 -*-
"""
ForestLens QGIS Plugin - Secure Storage

Handles secure storage of authentication credentials using system keyring.
Falls back to QGIS settings only if explicitly allowed (not for production).
"""

import json
from dataclasses import dataclass, asdict
from typing import Optional
from qgis.core import QgsMessageLog, Qgis

# Try to import keyring, but make it optional
try:
    import keyring
    KEYRING_AVAILABLE = True
except ImportError:
    KEYRING_AVAILABLE = False
    keyring = None

from .constants import KEYRING_SERVICE_NAME, ALLOW_INSECURE_STORAGE_FALLBACK


@dataclass
class StoredCredentials:
    """Authentication credentials stored securely."""
    access_token: str
    refresh_token: str
    user_email: str
    user_id: str
    expires_at: int
    last_activity: int


class SecureStorage:
    """
    Secure storage manager using system keyring.

    Credentials are encrypted at rest using the operating system's
    credential manager (Windows Credential Manager, macOS Keychain,
    Linux Secret Service).
    """

    def __init__(self):
        """Initialize secure storage and check keyring availability."""
        if not KEYRING_AVAILABLE:
            self._available = False
            self._log("Keyring module not installed - secure storage unavailable", Qgis.Warning)
            if not ALLOW_INSECURE_STORAGE_FALLBACK:
                self._log("Insecure storage fallback is disabled", Qgis.Critical)
        else:
            self._available = self._check_keyring()
            if not self._available:
                self._log("System keyring not available", Qgis.Warning)
                if not ALLOW_INSECURE_STORAGE_FALLBACK:
                    self._log("Insecure storage fallback is disabled", Qgis.Critical)

    def _log(self, message: str, level: Qgis.MessageLevel = Qgis.Info):
        """Log message to QGIS log panel."""
        QgsMessageLog.logMessage(message, 'ForestLens-Storage', level)

    def _check_keyring(self) -> bool:
        """
        Check if system keyring is available and working.

        Returns:
            bool: True if keyring is functional, False otherwise
        """
        if not KEYRING_AVAILABLE or keyring is None:
            return False

        try:
            test_key = f"{KEYRING_SERVICE_NAME}-test"
            keyring.set_password(KEYRING_SERVICE_NAME, test_key, "test")
            result = keyring.get_password(KEYRING_SERVICE_NAME, test_key)
            keyring.delete_password(KEYRING_SERVICE_NAME, test_key)
            return result == "test"
        except Exception as e:
            self._log(f"Keyring test failed: {str(e)}", Qgis.Warning)
            return False

    @property
    def is_available(self) -> bool:
        """Check if secure storage is available."""
        return self._available

    def store_credentials(self, creds: StoredCredentials) -> bool:
        """
        Store credentials securely in system keyring.

        Args:
            creds: Credentials to store

        Returns:
            bool: True if successful, False otherwise
        """
        if not self._available or not KEYRING_AVAILABLE or keyring is None:
            if not ALLOW_INSECURE_STORAGE_FALLBACK:
                self._log("Cannot store credentials: keyring unavailable and fallback disabled", Qgis.Critical)
                return False
            self._log("WARNING: Storing credentials without encryption (fallback mode)", Qgis.Warning)
            return False

        try:
            keyring.set_password(
                KEYRING_SERVICE_NAME,
                "credentials",
                json.dumps(asdict(creds))
            )
            self._log("Credentials stored securely")
            return True
        except Exception as e:
            self._log(f"Failed to store credentials: {str(e)}", Qgis.Critical)
            return False

    def get_credentials(self) -> Optional[StoredCredentials]:
        """
        Retrieve credentials from secure storage.

        Returns:
            StoredCredentials if found, None otherwise
        """
        if not self._available or not KEYRING_AVAILABLE or keyring is None:
            return None

        try:
            data = keyring.get_password(KEYRING_SERVICE_NAME, "credentials")
            if data:
                return StoredCredentials(**json.loads(data))
            return None
        except Exception as e:
            self._log(f"Failed to retrieve credentials: {str(e)}", Qgis.Warning)
            return None

    def clear_credentials(self) -> bool:
        """
        Clear stored credentials.

        Returns:
            bool: True if successful, False otherwise
        """
        if not KEYRING_AVAILABLE or keyring is None:
            return True

        try:
            keyring.delete_password(KEYRING_SERVICE_NAME, "credentials")
            self._log("Credentials cleared")
            return True
        except Exception as e:
            # Check if it's a PasswordDeleteError (credentials didn't exist)
            if "PasswordDeleteError" in str(type(e).__name__):
                return True
            self._log(f"Failed to clear credentials: {str(e)}", Qgis.Warning)
            return False
