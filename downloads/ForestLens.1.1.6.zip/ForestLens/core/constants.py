# -*- coding: utf-8 -*-
"""
ForestLens QGIS Plugin - Constants and Configuration
"""

# API URLs
FORESTLENS_API_URL = "https://forestlens.com"  # Production
FORESTLENS_API_URL_DEV = "http://localhost:3000"  # Development

# Supabase Configuration
# Note: These are PUBLIC anon keys - safe to include in client code
SUPABASE_URL = "https://xmnzsfkamjdqcwabhzow.supabase.co"
SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhtbnpzZmthbWpkcWN3YWJoem93Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTQ3NDIzMDAsImV4cCI6MjA3MDMxODMwMH0.GlroPsBceJLwJ5p90L7dEAHVQpAUtV3Bko42Nyp6BR4"

# Analysis Types
ANALYSIS_TYPES = {
    'linear_regression': {
        'name': 'Linear Regression',
        'description': 'Long-term NDVI trend analysis',
        'requires_pro': False
    },
    'theil_sen': {
        'name': 'Theil-Sen Estimator',
        'description': 'Robust trend detection',
        'requires_pro': False
    },
    'ndvi_anomaly': {
        'name': 'NDVI Anomaly Detection',
        'description': 'Compare to historical baseline',
        'requires_pro': False
    },
    'forest_change_detector': {
        'name': 'Forest Change Detector',
        'description': '19-category forest dynamics classification',
        'requires_pro': True
    }
}

# Default Analysis Configuration
DEFAULT_CONFIG = {
    'target_months': [6, 7, 8],  # Default: June, July, August (matches web app)
    'max_cloud_coverage': 5,  # 5% default for better quality
    'pixel_eval_max_value': 0.02
}

# Plugin Settings Keys
SETTINGS_GROUP = "ForestLens"
SETTINGS_KEYS = {
    'api_url': 'api_url',
    'use_dev_server': 'use_dev_server'
}

# Security Constants
SESSION_TIMEOUT_SECONDS = 7 * 24 * 60 * 60      # 7 days
SESSION_IDLE_TIMEOUT_SECONDS = 24 * 60 * 60     # 24 hours
TOKEN_REFRESH_BUFFER_SECONDS = 5 * 60           # 5 minutes

ALLOW_INSECURE_STORAGE_FALLBACK = False         # MUST be False in production
KEYRING_SERVICE_NAME = "ForestLens-QGIS-Plugin"

# Request Timeouts (seconds)
TIMEOUT_AUTH = 30
TIMEOUT_ANALYSIS = 300  # 5 minutes for large areas

# Geometry Limits
MAX_GEOMETRY_VERTICES = 10000
MAX_GEOMETRY_AREA_SQ_KM = 1000  # ~1000 km²
