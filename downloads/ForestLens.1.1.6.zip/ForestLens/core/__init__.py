# -*- coding: utf-8 -*-
"""
ForestLens QGIS Plugin - Core Module
"""
