# -*- coding: utf-8 -*-
"""
ForestLens QGIS Plugin - Evalscript Generator

Generates evalscripts for CDSE API requests.
Core calculation logic is obfuscated to protect IP.
"""

from typing import Dict, List
from datetime import datetime


class EvalscriptGenerator:
    """Generates evalscripts for different analysis types."""

    @staticmethod
    def generate_linear_regression(
        start_year: int,
        end_year: int,
        target_months: List[int],
        max_cloud_coverage: int,
        pixel_eval_max_value: float = 0.02
    ) -> str:
        """Generate Linear Regression evalscript."""

        months_str = ', '.join(str(m) for m in target_months)

        return f"""//VERSION=3
/*
True Linear Regression Analysis for NDVI Trend Detection
*/

const param = {{
  default: {{
    startYear: {start_year},
    endYear: {end_year},
    targetMonths: [{months_str}],
    maxCloudCoveragePercent: {max_cloud_coverage},
    ndviMinValue: -1,
    currentIndexesMinValuesNumber: 1
  }},
  linearRegression: {{
    pixelEvalMaxValue: {pixel_eval_max_value}
  }}
}};

function setup() {{
  return {{
    input: [{{
      bands: ["B04", "B08", "SCL", "dataMask"]
    }}],
    output: {{ bands: 3 }},
    mosaicking: "ORBIT"
  }};
}}

function preProcessScenes(collections) {{
  const startYear = param.default.startYear;
  const endYear = param.default.endYear;
  const maxCloudCoveragePercent = param.default.maxCloudCoveragePercent;
  const targetMonths = param.default.targetMonths;

  collections.scenes.orbits = collections.scenes.orbits.filter(function (orbit) {{
    var orbitDateFrom = new Date(orbit.dateFrom);
    var orbitYear = orbitDateFrom.getFullYear();
    var currentMonth = orbitDateFrom.getMonth() + 1;

    var isCorrectYearRange = orbitYear >= startYear && orbitYear <= endYear;
    var isCorrectMonth = targetMonths.indexOf(currentMonth) !== -1;
    var isLowCloudCoverage = !orbit.cloudCoverage || orbit.cloudCoverage < maxCloudCoveragePercent;

    return isCorrectYearRange && isCorrectMonth && isLowCloudCoverage;
  }});

  return collections;
}}

var calculateNDVI = function calculateNDVI(sample, configParam) {{
  var denom = sample.B04 + sample.B08;
  if (denom === 0) return null;
  var result = (sample.B08 - sample.B04) / denom;
  return result > configParam.ndviMinValue ? result : null;
}};

var isSLCMasked = function isSLCMasked(sample) {{
  if (sample.SCL !== undefined && sample.SCL !== null) {{
    return (
      sample.SCL === 0 || sample.SCL === 1 || sample.SCL === 3 ||
      sample.SCL === 8 || sample.SCL === 9 || sample.SCL === 10 || sample.SCL === 11
    );
  }}
  return false;
}};

var calculateIndexesForSamples = function calculateIndexesForSamples(samples, scenes, configParam, processSampleMethod) {{
  if (samples.length !== scenes.length) throw new Error('samples and scenes arrays do not have same length');

  return samples.reduce(function (acc, sample, index) {{
    if (isSLCMasked(sample)) return acc;

    var indexValue = processSampleMethod(sample, configParam);
    if (!indexValue) return acc;

    var sceneYear = scenes[index].date.getFullYear();

    if (!acc[sceneYear]) {{
      acc[sceneYear] = {{ count: 0, sum: 0 }};
    }}

    acc[sceneYear].count++;
    acc[sceneYear].sum += indexValue;
    return acc;
  }}, {{}});
}};

function calculateLinearRegression(indexes, startYear, endYear) {{
  var dataPoints = [];

  for (var year = startYear; year <= endYear; year++) {{
    if (indexes[year] && indexes[year].count > 0) {{
      var yearlyAverage = indexes[year].sum / indexes[year].count;
      dataPoints.push({{ year: year, ndvi: yearlyAverage }});
    }}
  }}

  if (dataPoints.length < 2) return null;
  if (endYear <= startYear) return null;

  var n = dataPoints.length;
  var sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;

  for (var i = 0; i < n; i++) {{
    sumX += dataPoints[i].year;
    sumY += dataPoints[i].ndvi;
    sumXY += dataPoints[i].year * dataPoints[i].ndvi;
    sumX2 += dataPoints[i].year * dataPoints[i].year;
  }}

  var denominator = n * sumX2 - sumX * sumX;
  if (denominator === 0) return null;

  var slope = (n * sumXY - sumX * sumY) / denominator;
  var intercept = (sumY - slope * sumX) / n;

  return {{
    slope: slope,
    intercept: intercept,
    dataPoints: dataPoints,
    yearSpan: endYear - startYear
  }};
}}

function evaluatePixel(samples, scenes) {{
  var indexes = calculateIndexesForSamples(samples, scenes, param["default"], calculateNDVI);
  var regression = calculateLinearRegression(indexes, param.default.startYear, param.default.endYear);

  if (!regression) return [0, 0, 0];

  var totalChange = regression.slope * regression.yearSpan;
  var clampedChange = Math.max(-param.linearRegression.pixelEvalMaxValue,
                               Math.min(param.linearRegression.pixelEvalMaxValue, totalChange));

  return valueInterpolate(
    clampedChange,
    [-param.linearRegression.pixelEvalMaxValue, 0, param.linearRegression.pixelEvalMaxValue],
    [[1, 0, 0], [1, 1, 1], [0, 1, 0]]
  );
}}

function valueInterpolate(val, inputRange, outputRange) {{
  if (val <= inputRange[0]) return outputRange[0];
  if (val >= inputRange[inputRange.length - 1]) return outputRange[outputRange.length - 1];

  for (var i = 0; i < inputRange.length - 1; i++) {{
    if (val >= inputRange[i] && val <= inputRange[i + 1]) {{
      var t = (val - inputRange[i]) / (inputRange[i + 1] - inputRange[i]);
      return [
        outputRange[i][0] + t * (outputRange[i + 1][0] - outputRange[i][0]),
        outputRange[i][1] + t * (outputRange[i + 1][1] - outputRange[i][1]),
        outputRange[i][2] + t * (outputRange[i + 1][2] - outputRange[i][2])
      ];
    }}
  }}
  return outputRange[0];
}}"""

    @staticmethod
    def get_current_year() -> int:
        """Get current year for default end year."""
        return datetime.now().year
