#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ForestLens QGIS Plugin - Packaging Script

Creates a ZIP file suitable for installation in QGIS.
"""

import os
import zipfile
from pathlib import Path


def create_plugin_zip():
    """Create plugin ZIP file for distribution."""

    # Get plugin directory
    script_dir = Path(__file__).parent
    plugin_dir = script_dir.parent
    root_dir = plugin_dir.parent

    # Plugin name
    plugin_name = "forestlens_qgis"

    # Output file
    output_file = root_dir / f"{plugin_name}.zip"

    # Files and directories to include
    include_patterns = [
        "**/*.py",
        "**/*.txt",
        "**/*.md",
        "**/*.qml",
        "**/*.png",
        "**/*.svg",
        "**/*.ui",
        "**/*.qrc",
    ]

    # Directories to exclude
    exclude_dirs = {
        "__pycache__",
        ".git",
        ".pytest_cache",
        "tests",
        "scripts",
        ".vscode",
        ".idea",
    }

    print(f"Creating plugin package: {output_file}")
    print(f"Source directory: {plugin_dir}")

    files_added = 0

    with zipfile.ZipFile(output_file, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for pattern in include_patterns:
            for file_path in plugin_dir.rglob(pattern):
                # Skip if in excluded directory
                if any(excl in file_path.parts for excl in exclude_dirs):
                    continue

                # Get relative path from plugin_dir
                rel_path_from_plugin = file_path.relative_to(plugin_dir)

                # Create path with root directory: forestlens_qgis/file.py
                zip_path = Path(plugin_name) / rel_path_from_plugin

                # Add to ZIP with root directory structure
                zipf.write(file_path, zip_path)
                files_added += 1
                print(f"  Added: {zip_path}")

    print(f"\nPackage created successfully!")
    print(f"Files added: {files_added}")
    print(f"Output file: {output_file}")
    print(f"Size: {output_file.stat().st_size / 1024:.1f} KB")

    return output_file


if __name__ == "__main__":
    create_plugin_zip()
