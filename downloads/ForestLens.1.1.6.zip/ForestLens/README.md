# ForestLens QGIS Plugin

Professional forest health monitoring using Sentinel-2 satellite data, directly in QGIS.

## Features

- **Linear Regression** - Long-term NDVI trend analysis
- **Theil-Sen Estimator** - Robust trend detection resistant to outliers
- **NDVI Anomaly Detection** - Compare current conditions to historical baseline
- **Forest Change Detector** - 19-category classification of forest dynamics

## Requirements

- QGIS 3.28 or higher
- ForestLens account ([forestlens.com](https://forestlens.com))
- CDSE credentials configured in ForestLens web app

## Installation

### From QGIS Plugin Repository (Recommended)

1. Open QGIS
2. Go to **Plugins → Manage and Install Plugins**
3. Search for "ForestLens"
4. Click **Install Plugin**

### Manual Installation

1. Download the latest release ZIP file
2. Open QGIS
3. Go to **Plugins → Manage and Install Plugins → Install from ZIP**
4. Select the downloaded ZIP file
5. Click **Install Plugin**

## Setup

1. **Install the plugin** (see above)
2. **Login** with your ForestLens credentials
   - Click the ForestLens toolbar icon
   - Click "Login" button
   - Enter your email and password
3. **Configure CDSE credentials** (if not already done)
   - Visit ForestLens web app
   - Go to **Admin → Key User → Credentials**
   - Enter your CDSE client ID and secret

## Usage

### Running an Analysis

1. **Load a vector layer** with polygon features (e.g., forest parcels)
2. **Select a feature** to analyze
3. **Open ForestLens panel**:
   - Click the ForestLens toolbar icon
   - Or go to **Plugins → ForestLens → ForestLens Analysis**
4. **Configure analysis**:
   - Select analysis type
   - Set time period (start year, end year)
   - Adjust parameters (cloud coverage, etc.)
5. **Run Analysis**:
   - Click "Run Analysis" button
   - Wait for processing (typically 30-120 seconds)
6. **View Results**:
   - GeoTIFF layer is automatically added to your project
   - Results are styled with appropriate color scheme

### Analysis Types

#### 1. Linear Regression
Fits a linear regression through yearly NDVI averages to detect long-term vegetation trends.

**Output:** Red (declining) → White (stable) → Green (increasing)

**Use cases:**
- Long-term forest health monitoring
- Deforestation detection
- Reforestation progress tracking

#### 2. Theil-Sen Estimator
Robust trend estimation resistant to outliers. Uses median of pairwise slopes.

**Output:** Red (declining) → White (stable) → Green (increasing)

**Use cases:**
- Trend detection with noisy data
- Areas with seasonal variations
- Robust change detection

#### 3. NDVI Anomaly Detection
Detects vegetation anomalies by comparing current year to historical baseline.

**Output:** Red (negative anomaly) → White (normal) → Green (positive anomaly)

**Use cases:**
- Drought impact assessment
- Pest/disease outbreak detection
- Recovery monitoring after disturbance

#### 4. Forest Change Detector
Advanced 19-category classification of forest dynamics: degradation, stagnation, growth, stress, and regeneration patterns.

**Output:** 19 discrete categories with color-coded legend

**Use cases:**
- Detailed forest dynamics analysis
- Silviculture planning
- Conservation monitoring

## Security

### Credential Storage

- **System Keyring**: Your login credentials are stored encrypted using your operating system's credential manager:
  - **Windows**: Windows Credential Manager
  - **macOS**: Keychain
  - **Linux**: Secret Service (GNOME Keyring, KWallet, etc.)

- **Session Management**:
  - Sessions expire after 24 hours of inactivity
  - Absolute session limit of 7 days
  - Tokens are automatically refreshed

- **CDSE Credentials**: Never stored locally. Retrieved securely from ForestLens server when needed.

### IP Protection

- **Evalscripts stay server-side**: All analysis algorithms remain on ForestLens servers
- **Only results transferred**: QGIS plugin receives only the final GeoTIFF
- **Secure API**: All communication uses HTTPS with JWT authentication

## Troubleshooting

### "System keyring not available"

This warning appears if QGIS can't access your system's credential manager. The plugin will still work, but you'll need to login each time you start QGIS.

**Solutions:**
- **Windows**: Usually works out of the box
- **macOS**: Usually works out of the box
- **Linux**: Install `gnome-keyring` or `kwallet`

### "CDSE credentials not configured"

You need to configure your CDSE credentials in the ForestLens web app:

1. Visit [forestlens.com](https://forestlens.com)
2. Login to your account
3. Go to **Admin → Key User → Credentials**
4. Enter your CDSE client ID and secret
5. Return to QGIS and try again

### "No feature selected"

Make sure you have:
1. Loaded a vector layer with polygons
2. Selected exactly one feature
3. The feature is a valid polygon (not line or point)

### "Geometry too complex"

The selected geometry has too many vertices. Try:
1. Simplifying the geometry (Vector → Geometry Tools → Simplify)
2. Using a smaller area
3. Splitting into multiple smaller polygons

### Analysis timeout

Large areas may take longer than 5 minutes. Try:
1. Reducing the area size
2. Increasing the cloud coverage threshold (uses fewer scenes)
3. Shortening the time period

## Support

- **Documentation**: [forestlens.com/docs/qgis-plugin](https://forestlens.com/docs/qgis-plugin)
- **Issues**: [GitHub Issues](https://github.com/forestlens/qgis-plugin/issues)
- **Email**: support@forestlens.com

## License

Copyright (C) 2024 ForestLens

This plugin is proprietary software. Usage requires a valid ForestLens subscription.

## Data Attribution

This plugin uses Copernicus Sentinel-2 satellite data accessed through the Copernicus Data Space Ecosystem (CDSE).

When publishing results, please cite:
- **Satellite Data**: "Contains modified Copernicus Sentinel data [Year]"
- **Plugin**: "Analysis performed with ForestLens QGIS Plugin"
