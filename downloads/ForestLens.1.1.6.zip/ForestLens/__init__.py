# -*- coding: utf-8 -*-
"""
ForestLens QGIS Plugin
Professional forest health monitoring using Sentinel-2 satellite data.

Copyright (C) 2024 ForestLens
"""


def classFactory(iface):
    """
    Load ForestLensPlugin class from forestlens_plugin module.

    :param iface: A QGIS interface instance.
    :type iface: QgsInterface
    """
    from .forestlens_plugin import ForestLensPlugin
    return ForestLensPlugin(iface)
